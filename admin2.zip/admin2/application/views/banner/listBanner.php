<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/sidebar'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
	<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Category Tables</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Simple Tables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
	</section>
<!-- Main content -->
<section class="content">
<?php echo $this->session->flashdata('msg');?>
  <div class="container-fluid">
	<div class="row">
	  <div class="col-md-12">
		<div class="card">
		  <div class="card-body">
		  <?php //echo "<pre>";print_r($products);?>
			  <table class="table table-bordered ">
			 
                  <thead>
                    <tr>
						<th style="width: 10px">S.No</th>
						<th style="width: 20px">Banner Tittle</th>
						<th style="width: 10px">image</th>
						<th class="text-center">Action</th>
						<!--<th>
							<a href="<?php echo base_url('login');?>">
								<input type="button" value="login" id="loginbtn" name="regbtn">
							</a>
						</th>-->
                    </tr>
                  </thead>
                  <tbody>
				   <?php if(!empty($banner)):
				   foreach($banner as $r): ?>
                    <tr>
                      <td class=""><?php echo $r->bid;?></td>
                      <td><?php echo $r->bname;?></td>
                      <td><img src=" <?php echo $r->image ?>" alt="" width="100%" /></td>
					  
					  <td width="15%"><a  href="<?php echo  base_url('Banner/update_banner?bid='.$r->bid);?>" class="btn btn-info"  onclick="return confirm('Are you sure want to update ?')">banner</a> | <a href="<?php echo  base_url('Banner/deletebanner?bid='.$r->bid);?>" class="btn btn-danger" onclick="return confirm('Are you sure want to delete ?')">Delete</a></td>
                    </tr>
                   </tbody>
				   <?php  endforeach;  endif?>
                </table>
			</div>
<?php $this->load->view('include/footer'); ?>               

