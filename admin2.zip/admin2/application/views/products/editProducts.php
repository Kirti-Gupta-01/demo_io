<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/sidebar'); ?>

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Products</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php// echo base_url('dashboard');?>">Home</a></li>
              <li class="breadcrumb-item active">Add Category</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
<?php echo $this->session->flashdata('msg');?>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Update Products</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo base_url('Upload/updateProduct');?>" method="post" enctype="multipart/form-data">
			   <input type="hidden" name="hid" id="hid" value="<?php echo (!empty($res[0]->pid))?$res[0]->pid:"";?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Category</label>
                    <select name="catg_name" class="form-control" id="catg_name"  required="required">
					<option value="">--Select Category--</option>
					<?php
					if(!empty($catres)){
						foreach($catres as $catVal){
						?>
						<option value="<?php echo $catVal->cid; ?>" <?php echo (!empty($res[0]->category)&&$res[0]->category==$catVal->cid)?"selected":"";?>><?php echo $catVal->name; ?></option>
						<?php
						}
					}
					?>
					</select>
                  </div><div class="form-group">
                    <label for="exampleInputEmail1">Sub Category</label>
                   <select name="subcatg_name" class="form-control" id="subcatg_name"  required="required">
				   <?php if(!empty($res[0]->subcategory)){?>
				   <option value="<?php echo $res[0]->subcategory; ?>"><?php echo $res[0]->sbname; ?></option>
				   <?php }else{ ?>
					<option value="">--Select Sub Category--</option>
				   <?php } ?>
						
					</select>
                  </div><div class="form-group">
                    <label for="exampleInputEmail1">Child Category </label>
                   <select name="childcatg_name" class="form-control" id="childcatg_name"  required="required">
				   <?php if(!empty($res[0]->subcategory)){?>
					<option value="<?php echo $res[0]->childcategory; ?>"><?php echo $res[0]->ccname; ?></option>
				   <?php } else { ?>
				   <option value="">--Select Child Category--</option>
				   <?php } ?>
					</select>
                  </div><div class="form-group">
                    <label for="exampleInputEmail1">Products Name</label>
                    <input type="text" name="pname" class="form-control" id="catg" value="<?php echo (!empty($res[0]->pname))?$res[0]->pname:"";?>" placeholder="Add new Products" required="required">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Price</label>
                    <input type="text" name="price" class="form-control" id="catg" value="<?php echo (!empty($res[0]->price))?$res[0]->price:"";?>" placeholder="Add Price" required="required">
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">quantity</label>
                    <input type="text" name="qty" class="form-control" id="catg" value="<?php echo (!empty($res[0]->qty))?$res[0]->qty:"";?>" placeholder="Add Quantity" required="required">
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Image</label>
                    <input type="file" name="image" class="form-control" id="catg">
                    <input type="hidden" name="imageh" id="imageh" value="<?php echo $res[0]->image ?>">
					<img src="<?php echo $res[0]->image ?>" alt="" width="100px" height=
					'100px'/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Descreption</label>
                    <input type="text" name="descreption" class="form-control" id="catg" value="<?php echo (!empty($res[0]->descreption))?$res[0]->descreption:"";?>" placeholder="Descreption" required="required">
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Size</label>
                    <input type="text" name="size" class="form-control" id="catg" value="<?php echo (!empty($res[0]->size))?$res[0]->size:"";?>"  placeholder="Add new Category" required="required">
                  </div>
                   
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <input type="submit" class="btn btn-primary" value="Submit">
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
      
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    
  </div>
  <!-- /.content-wrapper -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        
        $('#catg_name').change(function () {
			 var categoryId = $(this).val();
			$("#subcatg_name").empty();
           //console.log("Selected Category ID: ", categoryId);
			
                    $.ajax({
                    url: '<?php echo base_url();?>Upload/getsubcatg_name', 
                    type: 'Post',
                    data: {categoryId: categoryId},
                    dataType: 'json',
                    success: function (response) {
                       console.log("Response from server:", response);

                        $('#subcatg_name').html('<option value="0">Select Subcategory</option>');

                        // Populate options with the fetched subcategories
                        $.each(response.subcatgres, function (key, value) {
                            $('#subcatg_name').append('<option value="' + value.id + '">' + value.name + '</option>');
                        });
                    }
                });
            
        });
    });
	
	
	
	
</script>
<script>
    $(document).ready(function () {
        
        $('#subcatg_name').change(function () {
			 var subcategoryId = $(this).val();
			$("#childcatg_name").empty();
           //console.log("Selected Category ID: ", categoryId);
			
                    $.ajax({
                    url: '<?php echo base_url();?>Upload/getchildcatg_name', 
                    type: 'Post',
                    data: {subcategoryId: subcategoryId},
                    dataType: 'json',
                    success: function (response) {
                       console.log("Response from server:", response);

                        $('#childcatg_name').html('<option value="0">Select Subcategory</option>');

                        // Populate options with the fetched subcategories
                        $.each(response.subcatgres, function (key, value) {
                            $('#childcatg_name').append('<option value="' + value.id + '">' + value.name + '</option>');
                        });
                    }
                });
            
        });
    });
	
	
	
	
</script>
<?php $this->load->view('include/footer'); ?>