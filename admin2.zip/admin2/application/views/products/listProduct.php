<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/sidebar'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
	<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Category Tables</h1>
          </div>
          <div class="col-sm-12">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Simple Tables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
	</section>
<!-- Main content -->
<section class="content">
<?php echo $this->session->flashdata('msg');?>
  <div class="container-fluid">
	<div class="row">
	  <div class="col-md-12">
		<div class="card">
		  <div class="card-body">
		  <?php //echo "<pre>";print_r($products);?>
			  <table class="table table-bordered ">
			 
                  <thead>
                    <tr>
						<th style="width: 10px">S.No</th>
						<th>Category</th>
						<th>Sub Category</th>
						<th>Child Category</th>
						<th>Products Name</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>decreption</th>
						<th>size</th>
						<th style="width: 20px">image</th>
						<th class="text-center">Action</th>
						<!--<th>
							<a href="<?php echo base_url('login');?>">
								<input type="button" value="login" id="loginbtn" name="regbtn">
							</a>
						</th>-->
                    </tr>
                  </thead>
                  <tbody>
				   <?php if(!empty($products)):
				   foreach($products as $r): ?>
                    <tr>
                      <td><?php echo $r->pid;?></td>
                      <td><?php echo $r->category;?></td>
                      <td><?php echo $r->subcategory;?></td>
                      <td><?php echo $r->childcategory;?></td>
                      <td><?php echo $r->pname;?></td>
                      <td><?php echo $r->price;?></td>
                      <td><?php echo $r->qty;?></td>
                      <td><?php echo $r->descreption;?></td>
                      <td><?php echo $r->size;?></td>
                      <td><img src=" <?php echo $r->image ?>" alt="" width="100%" /></td>
					  <td width="15%"><a  href="<?php echo  base_url('Upload/editproduct?pid='.$r->pid);?>" class="btn btn-info"  onclick="return confirm('Are you sure want to update ?')">Edit</a> | <a href="<?php echo  base_url('Upload/deleteproduct?pid='.$r->pid);?>" class="btn btn-danger" onclick="return confirm('Are you sure want to delete ?')">Delete</a></td>
                    </tr>
                   </tbody>
				   <?php  endforeach;  endif?>
                </table>
			</div>
<?php $this->load->view('include/footer'); ?>               

