<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/sidebar'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
	<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Category Tables</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Simple Tables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
	</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
	<div class="row">
	  <div class="col-md-6">
		<div class="card">
		  <div class="card-body">
		  <?php //echo "<pre>";print_r($categories);?>
			  <table class="table table-bordered">
			 
                  <thead>
                    <tr>
                      <th style="width: 10px">S.No</th>
                      <th>Category Name</th>
                      <th>Active/Inactive</th>
                    </tr>
                  </thead>
                  <tbody>
				   <?php foreach ($categories as $r): ?>
                    <tr>
                      <td><?php echo $r->cid;?></td>
                      <td><?php echo $r->name;?></td>
                      <td><?php echo $r->active_inactive;?></td>
                     <!-- <td>
                        <div class="progress progress-xs">
                          <div class="progress-bar progress-bar-danger" style="width: 55%"></div>
                        </div>
                      </td>	-->
                    </tr>
                   </tbody>
				   <?php endforeach; ?>
                </table>
		</div>
<?php $this->load->view('include/footer'); ?>               

