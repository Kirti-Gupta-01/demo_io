<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/sidebar'); ?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard v2</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Home</a></li>
              <li class="breadcrumb-item active">Add Child Category</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
<?php echo $this->session->flashdata('msg');?>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Child-Category</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo base_url('category/savechildCategory');?>" method="post">
                <div class="card-body">
				<?php //echo "<pre>";print_r($categories);?>
				<?php //echo "<pre>";print_r($subcategories);?>
				<div class="form-group">
				<label for="selCategory">Select Category:</label>
					<select class="form-control" id="category" name="catg">
						<option value="">--Select Category--</option>
						<?php foreach ($categories as $r): ?>
							<option value="<?php echo $r->cid; ?>"><?php echo $r->name; ?></option>
						<?php endforeach; ?>
					</select>
					</div>
				<div class="form-group">
				<label for="selCategory">Select Sub-Category:</label>
					<select class="form-control" id="subCategory" name="category">
						<option value="">--Please Select--</option>
					</select>
					</div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Add Child-Category</label>
                    <input type="text" name="name" class="form-control" id="catg" placeholder="Add new Category" required="required">
                  </div>
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="active" name="active" >
                    <label class="form-check-label" for="exampleCheck1">Active</label>
                  </div>
                </div>
                <!-- /.card-body -->

    


                <div class="card-footer">
                  <input type="submit" class="btn btn-primary" value="Submit">
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
      
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    
  </div>
  <!-- /.content-wrapper -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        
        $('#category').change(function () {
			$("#subCategory").empty();
            var categoryId = $(this).val();

                    $.ajax({
                    url: '<?php echo base_url();?>category/getSubcategories', 
                    type: 'post',
                    data: {categoryId: categoryId},
                    dataType: 'json',
                    success: function (response) {
                       
                        $('#subCategory').html('<option value="0">Select Subcategory</option>');

                        // Populate options with the fetched subcategories
                        $.each(response.subcatgres, function (key, value) {
                            $('#subCategory').append('<option value="' + value.id + '">' + value.name + '</option>');
                        });
                    }
                });
            
        });
    });
</script>
<?php $this->load->view('include/footer'); ?>