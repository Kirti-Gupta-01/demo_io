<?php $this->load->view('frontend/includes/header');      //error_reporting(0);?>
        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Cart</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="<?php echo base_url('home');?>">Home</a></li>
                <li class="breadcrumb-item active text-white">Cart</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Cart Page Start -->
        <div class="container-fluid py-5">
            <div class="container py-5">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">Products</th>
                            <th scope="col">Name</th>
                            <th scope="col">Price</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Total</th>
                            <th scope="col">Handle</th>
                          </tr>
                        </thead>
                        <tbody>
						<?php if($this->cart->total_items()>0) {
		  foreach($this->cart->contents() as $key=>$row ): ?>
		<tr>
			<th scope="row">
				<div class="d-flex align-items-center">
					<img src="<?php echo $row['image'];?>" class="img-fluid me-5 rounded-circle" style="width: 80px; height: 80px;" alt="">
				</div>
			</th>
			<td>
				<p class="mb-0 mt-4"><?php echo $row['name']; ;?></p>
			</td>
			<td>
				<p class="mb-0 mt-4">₹ : <?php echo $row['price'] ;?></p>
			</td>
	<td>
    <div class="input-group quantity mt-4" style="width: 100px;">
        <div class="input-group-prepend">
            <button class="btn btn-sm btn-minus rounded-circle bg-light border" data-row-id="<?= $row['rowid']; ?>">
                <i class="fa fa-minus"></i>
            </button>
        </div>
        <input type="text" class="form-control quantity-input form-control-sm text-center border-0" name="quantity" id="quantity-<?= $row['rowid'] ?>" value="<?= $row['qty']; ?>">
        <div class="input-group-append">
            <button class="btn btn-sm btn-plus rounded-circle bg-light border" data-row-id="<?= $row['rowid']; ?>">
                <i class="fa fa-plus"></i>
            </button>
        </div>
    </div>
</td>
<td><p class="mb-0 mt-4" id="subtotal-<?= $row['rowid']; ?>"><?= $row['subtotal']; ?></p>
</td>



			<td>
			<a href="<?php echo base_url('cart/removeItem/' . $row['rowid']); ?>" class="btn " onclick="return confirm('Are you sure?');"><i class="fa fa-times text-danger"></i></a>
			</td>				
		</tr>
     <?php endforeach; 	}  ?> 
                        </tbody>
                    </table>
                </div>
                <div class="mt-5">
                    <input type="text" class="border-0 border-bottom rounded me-5 py-3 mb-4" placeholder="Coupon Code">
                    <button class="btn border-secondary rounded-pill px-4 py-3 text-primary" type="button">Apply Coupon</button>
                </div>
                <div class="row g-4 justify-content-end">
                    <div class="col-8"></div>
                    <div class="col-sm-8 col-md-7 col-lg-6 col-xl-4">
                        <div class="bg-light rounded">
                            <div class="p-4">
                                <h1 class="display-6 mb-4">Cart <span class="fw-normal">Total</span></h1>
                                <div class="d-flex justify-content-between mb-4">
                                    <h5 class="mb-0 me-4">Subtotal:</h5>
                                    <p class="mb-0 mt-4" id="cart-total"> <?php echo $this->cart->total();  ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="mb-0 me-4">Shipping + GST</h5>
                                    <div class="">
                                        <p class="mb-0">Flat rate: Rs : free + 18%</p>
                                    </div>
                                </div>
								
                            </div>
                            <div class="py-4 mb-4 border-top border-bottom d-flex justify-content-between">
                                <h5 class="mb-0 ps-4 me-4">Total</h5>
                                <p class="mb-0 pe-4"><?php if($this->cart->total_items() > 0) ?>
								
		<?php $amount=$this->cart->total();
			//print_r($amount);
			$gstRate = 18;
		$gstAmount = ($amount * $gstRate) / 100;
		$totalAmount = $amount + $gstAmount;
		print_r($totalAmount);
		?>
		
		<!-- <?php //echo  base_url('Upload/deleteproduct?pid='.$r->pid);?> -->
															
								</p>
                            </div>
                            <button onclick="location.href='<?php echo base_url('cart/checkout'); ?>'" class="btn border-secondary rounded-pill px-4 py-3 text-primary text-uppercase mb-4 ms-4" type="button">Proceed to Checkout</button>
							
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Cart Page End -->


        <?php $this->load->view('frontend/includes/footer');?>
		</body>
		
		
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
$(document).ready(function() {
    $('.btn-plus, .btn-minus').on('click', function(e){ 
        //alert('a'); 
        const isPositive = $(e.currentTarget).hasClass('btn-plus');
        let input = $(e.currentTarget).closest('.input-group').find('.quantity-input'); 
        let currentValue = parseInt(input.val(), 10);
        currentValue = isPositive ? currentValue + 1 : (currentValue - 1 > 0 ? currentValue - 1 : 1);
        input.val(currentValue);

        let rowId = $(e.currentTarget).data('row-id') || input.data('row-id');

        updateCartQuantity(rowId, currentValue);
    });
});

function updateCartQuantity(rowId, currentValue) {
    $.ajax({
        url: '<?php echo base_url("cart/update_quantity");?>',
        type: 'POST',
        data: {
            rowId: rowId,
            quantity: currentValue
        },	
		
    success: function(response) {	
    var data = JSON.parse(response);  
    if (data.status === 'success') {
        // console.log(response);
        $('#quantity-' + data.rowId).val(data.new_quantity);
        $('#subtotal-' + rowId).text('Subtotal: ' + data.new_subtotal);
        $('#cart-total').text('Total: ' + data.new_total);

        console.log('Quantity updated successfully');
    } else {
       
        console.error('Error updating quantity');
    }
},

        error: function() {
            alert('Error 4 updating quantity');
        }
    });
}
</script>
<script>
// Example assuming you have quantity inputs with class 'cart-quantity'
document.querySelectorAll('.cart-quantity').forEach(item => {
    item.addEventListener('change', function() {
        const itemId = this.getAttribute('data-item-id'); // Assuming each input has a data attribute for ID
        const newQuantity = this.value;

        // Prepare data to send to server
        const data = {itemId: itemId, quantity: newQuantity};

        $.ajax({
        url: '<?php echo base_url("cart/total");?>',
        type: 'POST',
        data: {
            itemId: itemId,
			quantity: newQuantity
        },	
		    success: function(response) {	
    var data = JSON.parse(response);  
    if (data.status === 'success') {
        // console.log(response);
       
        console.log('Quantity updated successfully');
    } else {
       
        console.error('Error updating quantity');
    }
},
        .catch((error) => {
            console.error('Error:', error);
        });
    });
});

</script>
</html>