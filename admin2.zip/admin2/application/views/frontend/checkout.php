<?php $this->load->view('frontend/includes/header'); //error_reporting(0);?>
    
        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Checkout</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="<?phpecho base_url('home'); ?>">Home</a></li>
                <li class="breadcrumb-item active text-white">Checkout</li>
            </ol>
        </div>
        <!-- Single Page Header End -->
		
        <!-- Checkout Page Start -->
        <div class="container-fluid py-5">
            <div class="container py-5">
		
			 <h1 class="text-danger"><?php //echo $this->session->flashdata('cart_error');?></h1>
			 <h1 class="text-success"><?php echo $this->session->flashdata('cart_set');?></h1>
			
			<?php if($this->cart->total_items()>0) {
										foreach($this->cart->contents() as $key=>$row ): ?>
			
                <h1 class="mb-4">Billing details</h1>
                <form action="<?php echo base_url('Product/process_sale');?>" method="post">
                    <div class="row g-5">
                        <div class="col-md-12 col-lg-6 col-xl-7">
                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">First Name<sup>*</sup></label>
                                        <input type="text" class="form-control" name="name" id="name">
                                    </div>
                                </div>
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">Last Name<sup>*</sup></label>
                                        <input type="text" class="form-control" name="lname" id="lname">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-item">
                                <label class="form-label my-3">Address <sup>*</sup></label>
                                <input type="text" class="form-control" placeholder="House Number Street Name" name="add" id="add">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Town/City<sup>*</sup></label>
                                <input type="text" class="form-control" name="t_c" id="t_c">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Country<sup>*</sup></label>
                                <input type="text" class="form-control" name="cont" id="cont">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Postcode/Zip<sup>*</sup></label>
                                <input type="text" class="form-control" name="pin" id="pin">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Mobile<sup>*</sup></label>
                                <input type="tel" class="form-control" name="mob" id="mob">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Email Address<sup>*</sup></label>
                                <input type="email" class="form-control" name="eml" id="eml">
                            </div>
                            <div class="form-item">
                                <textarea  class="form-control" spellcheck="false" cols="30" rows="11" placeholder="Oreder Notes (Optional)" name="text" id="text"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6 col-xl-5">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Products</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
		<input type="hidden" name="products[<?= $row['rowid'] ?>][id]" value="<?= $row['id'] ?>">
    <input type="hidden" name="products[<?= $row['rowid'] ?>][qty]" value="<?= $row['qty'] ?>">							
                                        <tr>
                                            <th scope="row">
                                                <div class="d-flex align-items-center mt-2">
                                                    <img src="<?php echo $row['image'];?>" class="img-fluid me-5 rounded-circle" style="width: 80px; height: 80px;" alt="">
                                                </div>
                                            </th>
											
                                            <td class="py-5"><?php echo $row['name']; ;?></td>
                                            <td class="py-5">₹ : <?php  echo $row['price']; ;?></td>
                                            <td class="py-5"><?= $row['qty']; ?></td>
                                            <td class="py-5"><?= $row['subtotal']; ?></td>
                                        </tr>
                                        <?php endforeach; 	}  ?> 
                                        <tr>
                                                 
                                        </tr>
                                        <tr>
                                            <th scope="row">
                                            </th>
                                            <td class="py-5">
                                                <p class="mb-0 text-dark py-4">Shipping</p>
                                            </td>
                                            <td colspan="3" class="py-5">
                                                <div class="form-check text-start">
                                                    <input type="checkbox" class="form-check-input bg-primary border-0" id="Shipping-1" name="Shipping-1" value="Shipping">
                                                    <label class="form-check-label" for="Shipping-1">Free Shipping</label>
                                                </div>
                                                <div class="form-check text-start">
                                                    <input type="checkbox" class="form-check-input bg-primary border-0" id="Shipping-2" name="Shipping-1" value="Shipping">
                                                    <label class="form-check-label" for="Shipping-2">Flat rate: 1%</label>
                                                </div>
                                                <div class="form-check text-start">
                                                    <input type="checkbox" class="form-check-input bg-primary border-0" id="Shipping-3" name="Shipping-1" value="Shipping">
                                                    <label class="form-check-label" for="Shipping-3">GST : 18%</label>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">
                                            </th>
                                            <td class="py-5">
                                                <p class="mb-0 text-dark text-uppercase py-3">TOTAL</p>
                                            </td>
                                            <td class="py-5"></td>
                                            <td class="py-5"></td>
                                            <td class="py-5">
                                                <div class="py-3 border-bottom border-top">
                                                    <p class="mb-0 text-dark">
														<?php if($this->cart->total_items() > 0) ?>
														<?php $amount= $this->cart->total();
															//print_r($amount);
															$gstRate = 18+1;
														$gstAmount = ($amount * $gstRate) / 100;
														$totalAmount = $amount + $gstAmount;
														print_r($totalAmount);
														?>					
													</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>					
                                </table>
                            </div>
                           
                            <div class="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                <div class="col-12">
                                    <div class="form-check text-start my-3">
                                        <input type="checkbox" class="form-check-input bg-primary border-0" id="checkbox1" onclick="handleCheckboxClick(this);" name="Payments" value="Payments">
                                        <label class="form-check-label" for="Payments-1">Check Payments</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                <div class="col-12">
                                    <div class="form-check text-start my-3">
                                        <input type="checkbox" class="form-check-input bg-primary border-0" id="checkbox2" onclick="handleCheckboxClick(this);" name="Payments" value="Delivery">
                                        <label class="form-check-label" for="Delivery-1">Cash On Delivery</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                <div class="col-12">
                                    <div class="form-check text-start my-3">
                                        <input type="checkbox" class="form-check-input bg-primary border-0" id="checkbox1" onclick="handleCheckboxClick(this);" name="Payments" value="Paypal">
                                        <label class="form-check-label" for="Paypal-1">Paypal</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-4 text-center align-items-center justify-content-center pt-4">
                               
				
					<input type="submit" class="btn border-secondary py-3 px-4 text-uppercase w-100" value="Place Order" id="loginbtn" name="regbtn">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
		
        <!-- Checkout Page End -->


        <?php $this->load->view('frontend/includes/footer');?>
    </body>
<script>
	function handleCheckboxClick(clickedCheckbox) {
 
  const checkboxes = document.querySelectorAll('input[type="checkbox"]');

  checkboxes.forEach((checkbox) => {
    
    if (checkbox !== clickedCheckbox) {
      checkbox.checked = false; // Uncheck
      checkbox.disabled = true; // Disable
    } else {
      checkbox.disabled = false; // Ensure the clicked checkbox remains enabled
    }
  });

  // If the clicked checkbox was unchecked, re-enable all checkboxes
  if (!clickedCheckbox.checked) {
    checkboxes.forEach((checkbox) => {
      checkbox.disabled = false;
    });
  }
}
</script>
</html>