<!DOCTYPE html>
<!---Coding By CodingLab | www.codinglabweb.com--->
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <!--<title>Registration Form in HTML CSS</title>-->
    <!---Custom CSS File--->
    <link rel="stylesheet" href="style.css" />
  </head>
  <style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: #fff;
}
.container {
  position: relative;
  max-width: 700px;
  width: 100%;
  background: #fff;
  padding: 25px;
  border-radius: 8px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}
.container header {
  font-size: 1.5rem;
  color: #333;
  font-weight: 500;
  text-align: center;
}
.container .form {
  margin-top: 30px;
}
.form .input-box {
  width: 100%;
  margin-top: 20px;
}
.input-box label {
  color: #333;
}
.form :where(.input-box input, .select-box) {
position: relative;
height: 50px;
width: 100%;
outline: none;
font-size: 1rem;
color: #707070;
margin-top: 8px;
border: 1px solid #ddd;
border-radius: 6px;
padding: 0 15px;
}
.input-box input:focus {
box-shadow: 0 1px 0 rgba(0, 0, 0, 0.1);
}
.form .column {
display: flex;
column-gap: 15px;
}
.form .gender-box {
margin-top: 20px;
}
.gender-box h3 {
color: #333;
font-size: 1rem;
font-weight: 400;
margin-bottom: 8px;
}
.form :where(.gender-option, .gender) {
display: flex;
align-items: center;
column-gap: 50px;
flex-wrap: wrap;
}
.form .gender {
column-gap: 5px;
}
.gender input {
accent-color: rgb(130, 106, 251);
}
.form :where(.gender input, .gender label) {
cursor: pointer;
}
.gender label {
color: #707070;
}
.address :where(input, .select-box) {
margin-top: 15px;
}
.select-box select {
height: 100%;
width: 100%;
outline: none;
border: none;
color: #707070;
font-size: 1rem;
}
#regbtn{
height: 55px;
width: 50%;
color: #fff;
font-size: 1rem;
font-weight: 400;
margin-top: 30px;
border: none;
cursor: pointer;
transition: all 0.2s ease;
background: #81c408;
}
#loginbtn{
height: 55px;
width: 900%;
color: #fff;
font-size: 1rem;
font-weight: 400;
margin-top: 30px;
border: none;
cursor: pointer;
transition: all 0.2s ease;
background: #81c408;
}
.form button:hover {
  background: rgb(88, 56, 250);
}
/*Responsive*/
@media screen and (max-width: 500px) {
  .form .column {
    flex-wrap: wrap;
  }
  .form :where(.gender-option, .gender) {
    row-gap: 15px;
  }
}
</style>
   <script>
  
  	function vld(){
  	var un =document.getElementById("name").value;
  	 un=un.trim();
  	if(un==""){
  	  alert("Enter the Name");
  	  document.getElementById("name").focus();
  	  document.getElementById("name").value="";
  	  return false;
  	 }
  	if(un.length<3){
  	alert("Enter Ur Name Aleast 5 words:");
  	document.getElementById("name").focus();
     	return false;
  	 }
  	var letters = /^[A-Za-z ]+$/;
  		if( !(un.match(letters)) ){
  			alert("Enter only alphabates in Name");
  			document.getElementById("name").focus();
  			document.getElementById("name").value="";
  			return false;
  		}
  		
  		var em=document.getElementById("eml").value;
  		em=em.trim();
  		if( em=="" ){
  			alert("Plz Enter Email");
  			document.getElementById("eml").focus();
  			document.getElementById("eml").value="";
  			return false;
  		}else{
  			var atpos = em.indexOf("@");
  			var dotpos = em.lastIndexOf(".");
  			if (atpos<1 || dotpos<atpos+2 || dotpos+2>=em.length) {
  				alert("Not a valid e-mail address");
  				document.getElementById("eml").focus();
  				return false;
  			}
  		}
  		var mb=document.getElementById("mob").value;
  		mb=mb.trim();
  		if( mb=="" ){
  			alert("Plz Enter Mobile");
  			document.getElementById("mob").focus();
  			document.getElementById("mob").value="";
  			return false;
  		}
  		if( isNaN(mb) ){
  			alert("Enter only digits in Mobile");
  			document.getElementById("mob").focus();
  			document.getElementById("mob").value="";
  			return false;
  		}
  		if( mb.length!=10 ){
  			alert("Enter only 10 digit Mobile");
  			document.getElementById("mob").focus();
  			return false;
  		}
  		if( mb[0]<6 ){
  			alert("Enter a valid Mobile");
  			document.getElementById("mob").focus();
  			return false;
  		}
  	var pw=document.getElementById("pwd").value;
  		pw=pw.trim();
  		if( pw=="" ){
  			alert("Plz Enter 8 digit Password");
  			document.getElementById("pwd").focus();
  			document.getElementById("pwd").value="";
  			return false;
  		}
		var rp=document.getElementById("rpwd").value;
		rp=rp.trim();
		if( rp!= pw ){
			alert("Retype same Password Again ");
			document.getElementById("rpwd").focus();
			document.getElementById("rpwd").value="";
			return false;
		}
		
  		
  	}
   </script>
  <body>
    <section class="container">
      <header>Login Form</header>
	      <?php echo $this->session->flashdata('login_error');?>
	      <?php echo $this->session->flashdata('msg');?>
		  
		<form action="<?php echo base_url('registration/Auths');?>" class="form" method="post" onsubmit="return vld();">
			<div class="input-box">
				<label>Username</label>
				<input type="text" id="email"  name="email" placeholder="Enter your username" >
			</div>
			<div class="input-box">
				<label>Password</label>
				<input type="text" id="pwd" name="pwd" placeholder="Enter password"  >
			</div>
			<div class="column" >
				<input type="submit" value="login" id="regbtn" name="regbtn">
				
			</div>
		</form>
    </section>
  </body>
</html>