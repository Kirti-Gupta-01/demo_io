<?php $this->load->view('frontend/includes/header'); //error_reporting(0);?>
<body>
	<!-- Modal Search Start -->
		
		<div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-fullscreen">
				<div class="modal-content rounded-0">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body d-flex align-items-center">
						<div class="input-group w-75 mx-auto d-flex">
							<input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
							<span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- Modal Search End -->
	
	<!-- Hero Start -->		
	<div class="container-fluid py-5 mb-5 hero-header">
		<div class="container py-5">
			<div class="row g-5 align-items-center">
				<div class="col-md-12 col-lg-7">
					<h4 class="mb-3 text-secondary">100% original items Here </h4>
					<h1 class="mb-5 display-3 text-primary">Good for You, Good for the Planet</h1>
					<div class="position-relative mx-auto">
						<form action="<?php echo base_url('search/getSearch_product');?>" method="get">
							<input class="form-control border-2 border-secondary w-75 py-3 px-4 rounded-pill" type="search" name="search" id="search" placeholder="Search">
							<div>
						<div id="searchResults"></div>

							</div>
						</form>	
					</div>
				</div>
				<div class="col-md-12 col-lg-5">
					<?php if (!empty($banner)): ?>
					<div id="carouselId" class="carousel slide position-relative" data-bs-ride="carousel">
						<div class="carousel-inner" role="listbox">
							<?php foreach ($banner as $index => $bann): ?>
							<div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?> rounded">
								<img src="<?php echo $bann->image; ?>" class="img-fluid w-100 h-100 bg-secondary rounded" alt="Slide">
							</div>
							<?php endforeach; ?>
						</div>
						<button class="carousel-control-prev" type="button" data-bs-target="#carouselId" data-bs-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="visually-hidden">Previous</span>
						</button>
						<button class="carousel-control-next" type="button" data-bs-target="#carouselId" data-bs-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="visually-hidden">Next</span>
						</button>
					</div>
				</div>
			</div>
				<?php endif; ?>
		</div>
	</div>
	<!-- Hero End -->



	<!-- Fruits Shop Start-->
			
	<div class="container-fluid fruite py-5">
		<div class="container py-5">
			<div class="tab-class text-center">
				<div class="row g-4">
					<div class="col-lg-4 text-start">
						<h1>Our Products</h1>
					</div>
					<div class="col-lg-8 text-end">
						<ul class="nav nav-pills d-inline-flex text-center mb-5">
							<li class="nav-item">
								<a class="d-flex m-2 py-2 bg-light rounded-pill active" data-bs-toggle="pill" href="#tab-1">
									<span class="text-dark" style="width: 130px;">All Products</span>
								</a>
							</li>
							<?php if(!empty($category)){foreach($category as $catg) {
							?>
							<li class="nav-item">
								<a class="d-flex py-2 m-2 bg-light rounded-pill" data-bs-toggle="pill" href="#tab-<?php echo $catg->cid; ?>">
									<span class="text-dark" style="width: 130px;"><?php echo $catg->name; ?></span>
								</a>
							</li>
							<?php }} ?>
						</ul>
					</div>
				</div>
				<div class="tab-content">
					<div id="tab-1" class="tab-pane fade show p-0 active">			
					<div class="row g-4">
						<div class="col-lg-12">
							<div class="row g-4">
								<?php if(!empty($product_list)){
								foreach($product_list as $cd){
								?>
								<div class="col-md-6 col-lg-4 col-xl-3">
									<div class="rounded position-relative fruite-item">
									<div class="fruite-img">
	<a href="<?php echo base_url('product/details/' . $cd->pid); ?>" target="_blank">
    <img src="<?php echo $cd->image; ?>" class="img-fluid w-100 rounded-top" alt="Descriptive text about the image" style="max-height:200px;">
</a>
									</div>
									<div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;">Brand : <?php echo $cd->pname; ?></div>
									<div class="p-4 border border-secondary border-top-0 rounded-bottom">
									<h4>  <?php echo $cd->pname; ?></h4>
									<p><?php echo character_limiter($cd->descreption,4,'...'); ?></p>
									<div class="d-flex justify-content-between flex-lg-wrap">
									<p class="text-dark fs-5 fw-bold mb-0">Price : ₹ <?php echo $cd->price; ?></p>
									
									</div>
									</div>
									</div>
								</div>
								<?php }} ?>
							</div>
						</div>
					</div>
					</div>
					<?php if(!empty($category)){foreach($category as $catg2){
					?>
					<div id="tab-<?php echo $catg2->cid; ?>" class="tab-pane fade show p-0 ">			
					<div class="row g-4">
						<div class="col-lg-12">
							<div class="row g-4">
							<?php  
							$sql="select * from products where category=".$catg2->cid;
								$query=$this->db->query($sql);
								
								if(!empty($query->result())){
								foreach($query->result() as $cd2){
								?>
								<div class="col-md-6 col-lg-4 col-xl-3">
								<div class="rounded position-relative fruite-item">
								<div class="fruite-img">
	<a href="<?php echo base_url('product/details/' . $cd2->pid); ?>" target="_blank">
    <img src="<?php echo $cd2->image; ?>" class="img-fluid w-100 rounded-top" alt="Descriptive text about the image" style="max-height:200px;">
</a>
								</div>
								<div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;"> Brand : <?php echo $cd2->pname; ?></div>
								<div class="p-4 border border-secondary border-top-0 rounded-bottom">
									<h4>  <?php echo $cd2->pname; ?></h4>
									<p><?php echo character_limiter($cd2->descreption,4,'...'); ?></p>
								<div class="d-flex justify-content-between flex-lg-wrap">
									<p class="text-dark fs-5 fw-bold mb-0">Price : ₹<?php echo $cd2->price; ?></p>
									
									</div>
								</div>
								</div>
							</div>
							<?php }} ?>
							</div>
							</div>
						</div>
					</div>
					<?php } } ?>
				</div>      
			</div>
		</div>
	</div>
	
	<!-- Fruits Shop End-->
			
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script>
	$(document).ready(function(){
		$('#search').on('keyup', function(){
			var keyword = $(this).val();
		if(keyword.length > 0) {

			$.ajax({
				url: '<?php echo base_url();?>Search/search_prdct',
				type: 'POST',
				data: {keyword: keyword},
				success: function(response){
				$('#searchResults').html(response); // Displaying the search results
				},
				error: function(){
					$('#search-results').html('<p>Error loading the products.</p>');
				}
			});
			} else {
            $('#searchResults').empty(); // Clear results if the query is empty
        }

		});
	});
	</script>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script>
	$(document).ready(function() {
		$('#search-results').click(function(event) {
			event.preventDefault(); // Prevent the default link action
			
			// Retrieve product id and name from data attributes
			var productId = $(this).data('pid');
			var productName = $(this).data('pname');
			
			// Send the data to the server using AJAX
			$.ajax({
				url: '<?php echo base_url();?>Search/search_product',
				type: 'POST',
				data: {
					pid: productId,
					pname: productName
				},
				success: function(response) {
					
					console.log("Server response: ", response);
				},
				error: function(xhr, status, error) {
				   
					console.error("Error: " + status + " " + error);
				}
			});
		});
	});
	</script>
	<?php $this->load->view('frontend/includes/footer');?>

