<?php $this->load->view('frontend/includes/header'); //error_reporting(0);?>
	<style>
	
.star {
    color: gray;
    cursor: pointer;
}
.star.selected {
    color: gold;
}
</style>	
<script>
function vld() {
    // Validation for Name
    var un = document.getElementById("name").value.trim();
    if(un == "") {
        document.getElementById("nameError").textContent = "Please enter a name.";
        document.getElementById("name").focus();
        return false;
    }
    var letters = /^[A-Za-z ]+$/;
    if(!un.match(letters)) {
        document.getElementById("nameError").textContent = "Enter only alphabets in Name.";
        document.getElementById("name").focus();
        return false;
    } else {
        document.getElementById("nameError").textContent = ""; // Clear error message
    }

    // Validation for Email
    var em = document.getElementById("email").value.trim();
    if(em == "") {
        document.getElementById("emailError").textContent = "Please enter an email.";
        document.getElementById("email").focus();
        return false;
    } else {
        var atpos = em.indexOf("@");
        var dotpos = em.lastIndexOf(".");
        if(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= em.length) {
            document.getElementById("emailError").textContent = "Not a valid e-mail address.";
            document.getElementById("email").focus();
            return false;
        } else {
            document.getElementById("emailError").textContent = ""; // Clear error message
        }
    }

    // If more validations are needed, add them here before the return statement

    return true; // If all validations pass
}
</script>

        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Shop Detail</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="<?php echo base_url('home');?>">Home</a></li>
                <li class="breadcrumb-item active text-white">Shop Detail</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Single Product Start -->
        <div class="container-fluid py-5 mt-5">
            <div class="container py-5">
			<?php if(!empty($productDetails)){
					//print_r($productDetails);
					foreach($productDetails as $pd){
			?>
                <div class="row g-4 mb-5">
                    <div class="col-lg-8 col-xl-9">
                        <div class="row g-4">
                            <div class="col-lg-6">
                                <div class="border rounded">
                                    <a href="#">
                                        <img src="<?php echo $pd->image ?>" class="img-fluid rounded" alt="Image">
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-6">
							<?php $qty= $pd->qty ?>
							<?php if ($pd->stock <= $qty) {
    echo '<p style="color: red; font-size: 20px;">Product out of stock</p>';
} ?>

                                <h4 class="fw-bold mb-3"><strong><?php echo $pd->pname ?></strong></h4>
                                <p class="mb-3"><?php echo $pd->category ?></p>
                                <h5 class="fw-bold mb-3"><?php echo $pd->price ?></h5>
                                
                                <p class="mb-4"><?php echo $pd->descreption ?></p>
          
                                <div class="input-group quantity mb-5" style="width: 100px;">
     
	  <form action="<?php echo base_url('Shop_cart/insertcart');?>"  class="text-center" method="post" >
	  <input type="hidden" name="pid" value="<?php echo $pd->pid;  ?>">
      <input  type="submit" value="Add cart" class="btn btn-primary">
	  </form>
       </div>
	    </div>
	   
      <div class="col-lg-12">
      <nav>
        <div class="nav nav-tabs mb-3">
           <button class="nav-link active border-white border-bottom-0" type="button" role="tab"
           id="nav-about-tab" data-bs-toggle="tab" data-bs-target="#nav-about                                aria-controls="nav-about" aria-selected="true">Description</button>
		   <button class="nav-link border-white border-bottom-0" id="fetchDataButton" type="button" role="tab"
                                            id="nav-mission-tab" data-bs-toggle="tab" data-bs-target="#nav-mission"
                                            aria-controls="nav-mission" aria-selected="false">Reviews</button>
                                    </div>
                                </nav>
           <div class="tab-content mb-5">
      <div class="tab-pane active" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab">
         <p><?php echo $pd->descreption ?></p>
             <div class="px-2">
            <div class="row g-4">
            <div class="col-6">
                                                    <div class="row bg-light align-items-center text-center justify-content-center py-2">
                                                        <div class="col-6">
														<p class="mb-0"> size :</p>
                                                        </div>
                                                        <div class="col-6">
                                                            <p class="mb-0"><?php echo $pd->size ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="row text-center align-items-center justify-content-center py-2">
                                                        <div class="col-6">
                                                            <p class="mb-0">Country</p>
                                                        </div>
                                                        <div class="col-6">
                                                            <p class="mb-0">Made in India</p>
                                                        </div>
                                                    </div>
                                                    <div class="row bg-light text-center align-items-center justify-content-center py-2">
                                                        
                                                        <div class="col-6">
															<p class="mb-0"><?php echo $pd->qty ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="row text-center align-items-center justify-content-center py-2">
                                                        <div class="col-6">
                                                            <p class="mb-0">Сheck</p>
                                                        </div>
                                                        <div class="col-6">
                                                            <p class="mb-0">best quality</p>
                                                        </div>
                                                    </div>
                                                    <div class="row bg-light text-center align-items-center justify-content-center py-2">
                                                        <div class="col-6">
                                                            <p class="mb-0">Min Weight</p>
                                                        </div>
                                                        <div class="col-6">
                                                            <p class="mb-0">250 Kg</p>
                                                        </div>
                                                    </div>
                                                </div>
		</div>
	</div>
</div>
                                    <div class="tab-pane" id="nav-mission" role="tabpanel" aria-labelledby="nav-mission-tab">
                                        <?php if(!empty($reviewlist)){
											foreach($reviewlist as $rw){ ?>
										<div class="d-flex">
                                            <div class="">
                                                <p class="mb-2" style="font-size: 14px;"><?php echo $rw->date?></p>
                                                <div class="d-flex justify-content-between">
                                                    <h5><?php echo $rw->name?></h5>
                                                    <div class="d-flex mb-3">
                                                         <?php 
    // Print full stars based on $rw->star value
    for($i = 1; $i <= $rw->star; $i++) {
        echo '<i class="fa fa-star text-warning"></i>'; // Change 'text-primary' to the class you use for full stars
    }
    // Print empty stars for the remaining
    for($j = $rw->star + 1; $j <= 5; $j++) {
        echo '<i class="fa fa-star"></i>';
    }
    ?>
                                                    </div>
                                                </div>
                                                <p><?php echo $rw->review?> </p>
                                            </div>
                                        </div>
			<?php } } ?>
                                    </div>
                                    <div class="tab-pane" id="nav-vision" role="tabpanel">
                                        <p class="text-dark">Tempor erat elitr rebum at clita. Diam dolor diam ipsum et tempor sit. Aliqu diam
                                            amet diam et eos labore. 3</p>
                                        <p class="mb-0">Diam dolor diam ipsum et tempor sit. Aliqu diam amet diam et eos labore.
                                            Clita erat ipsum et lorem et sit</p>
                                    </div>
                                </div>
                            </div>
<form action="#" method="post" onclick="return vld();">
    <h4 class="mb-5 fw-bold">Leave a Reply</h4>
	<?php echo $this->session->flashdata('login_form');?>
    <div class="row g-4">
	
	<?php if (isset($reviewData)) {
    echo "Product ID: " . $reviewData['product_id'] . "<br>";
    echo "Rating: " . $reviewData['star'] . "<br>";
    echo "Name: " . $reviewData['name'] . "<br>";
    echo "Email: " . $reviewData['email'] . "<br>";
    echo "Review: " . $reviewData['review'] . "<br>";
	}
	?>
        <div class="col-lg-6">
			<?php if(!empty($productDetails)){
			//print_r($productDetails);
				foreach($productDetails as $cd){ ?>
                <input type="hidden" name="idd" id="idd" value="<?php echo $cd->pid; ?>" required="required">
			<?php } } ?>
			
			
            <div class="border-bottom rounded">
			<div id="nameError" class="error"></div>
                <input type="text" name="name" id="name" class="form-control border-0 me-4" placeholder="Your Name *" required="required">
                <span id="nameError" class="text-danger"></span>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="border-bottom rounded">
                <input type="email" name="email" id="email" class="form-control border-0" placeholder="Your Email *" required="required">
                <span id="emailError" class="text-danger"></span>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="border-bottom rounded my-4">
                <textarea name="review" id="review" class="form-control border-0" cols="30" rows="8" placeholder="Your Review *" spellcheck="false" required></textarea>
                <span id="reviewError" class="text-danger"></span>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="d-flex justify-content-between py-3 mb-5">
                <div class="d-flex align-items-center">
                    <p class="mb-0 me-3">Please rate:</p>
                    <div class="d-flex align-items-center" style="font-size: 20px;">
                        <div id="rating" required>
                            <span class="fa fa-star star" data-rating="1"></span>
                            <span class="fa fa-star star" data-rating="2"></span>
                            <span class="fa fa-star star" data-rating="3"></span>
                            <span class="fa fa-star star" data-rating="4"></span>
                            <span class="fa fa-star star" data-rating="5"></span>
                        </div>
                    </div>
                    <span id="ratingError" class="text-danger"></span>
                </div>
                <button id="submitReview" type="button" class="btn border border-secondary text-primary rounded-pill px-4 py-3" width="50%">Post Comment</button>

            </div>
        </div>
    </div>
</form>
 </div>
						<?php } }  ?>
                    </div>
                    <div class="col-lg-4 col-xl-3">
                       <div class="row g-4 fruite">
							<h4 class="mb-3 text-secondary">Discover more choices and find exactly what you're looking for with our extensive product selection.</h4>
                          
                                <div class="d-flex justify-content-center my-4">
                                    <a href="<?php echo base_url('Search/getSearchlist');?>" class="btn border border-secondary px-4 py-3 rounded-pill text-primary w-100">View More </a>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
                <h1 class="fw-bold mb-0">Related products</h1><br><br>
                <div class="vesitable">
				
					<div class="row g-4">
						<div class="col-lg-12">
							<div class="row g-4">
								<?php if(!empty($product_list)){
								foreach($product_list as $cd){
								?>
								<div class="col-md-6 col-lg-4 col-xl-3">
									<div class="rounded position-relative fruite-item">
									<div class="fruite-img">
	<a href="<?php echo base_url('product/details/' . $cd->pid); ?>" target="_blank">
    <img src="<?php echo $cd->image; ?>" class="img-fluid w-100 rounded-top" alt="Descriptive text about the image" style="max-height:200px;">
</a>
									</div>
									<div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;"><?php echo $cd->pname; ?></div>
									<div class="p-4 border border-secondary border-top-0 rounded-bottom">
									<h4>  <?php echo $cd->pname; ?></h4>
									<p><?php echo character_limiter($cd->descreption,4,'...'); ?></p>
									<div class="d-flex justify-content-between flex-lg-wrap">
									<p class="text-dark fs-5 fw-bold mb-0"><?php echo $cd->price; ?></p>
									<form action="<?php echo base_url('Shop_cart/insertcart');?>"  class="text-center" method="post" >
	  <input type="hidden" name="pid" value="<?php echo $cd->pid;  ?>">
      <input  type="submit" value="Add cart" class="btn btn-primary">
	  </form>
									</div>
									</div>
									</div>
								</div>
								<?php }} ?>
							</div>
						</div>
					</div>                            
                
                </div>
            </div>
			
		</div>
        <!-- Single Product End -->
        <?php $this->load->view('frontend/includes/footer');?>
		
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
</script>
    <script>
    $(document).ready(function() {
    var rating = 0;

    $('.star').click(function() {
        rating = $(this).data('rating');

        
        $('.star').removeClass('selected');

        $(this).addClass('selected');
        $(this).prevAll('.star').addClass('selected');
    });

    $('#submitReview').click(function(e) {
        e.preventDefault();
        var product_id = $('#idd').val();
        var name = $('#name').val();
        var email = $('#email').val();
        var review_text = $('#review').val();
        $.ajax({
            url: '<?php echo base_url('Home/review');?>', 
            type: 'POST',
            data: {
                rating: rating,
                product_id: product_id,
                name: name,
                email: email,
                review_text: review_text
            },
            success: function(response) {
                var res = JSON.parse(response);
               console.log(res);
                if(res.status === 'success') {
                    alert('Rating successfully saved.');
					location.reload();
                } else {
                   
                    alert('Error saving rating.');
                }
            },
        });
    });
});
</script>
    </body>
</html>