<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="style.css"> <!-- Link to your CSS file -->
</head>
<style>
/* style.css */
.feedback-form-container {
    max-width: 600px;
    margin: auto;
    padding: 20px;
    background-color: #f2f2f2;
    border-radius: 5px;
}

form h2 {
    text-align: center;
}

form label {
    display: block;
    margin-top: 10px;
}

form input[type="text"],
form input[type="email"],
form select,
form textarea {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box; /* Makes sure the padding doesn't increase the width */
}

form button[type="submit"] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 15px 20px;
    margin-top: 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

form button[type="submit"]:hover {
    background-color: #45a049;
}

</style>
<body>

<div class="feedback-form-container">
    <form action="<?php echo base_url('Testmonial/feedbackdata');?>" method="post">
        <h2>Feedback Form</h2>
        
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="rating">Rating:</label>
        <select id="rating" name="rating">
			<option value="Excellent">Excellent</option>
			<option value="Very Good">Very Good</option>
			<option value="Good">Good</option>
			<option value="Fair">Fair</option>
			<option value="Poor">Poor</option>
		</select>
        
        <label for="feedback">Feedback:</label>
        <textarea id="feedback" name="feedback" rows="4" required></textarea>
        
        <button type="submit" name="submit" id="submit">Submit Feedback</button>
    </form>
</div>

</body>
</html>
