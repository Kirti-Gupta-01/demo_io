<?php
class Search_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    // Method to search products by keyword
    public function search_products($keyword) {
        $this->db->select('cate.cid, cate.name as cname, sub.id as subid, sub.name as subname, child.id as childid, child.name as childname');
        $this->db->from('categories as cate');
        $this->db->join('subcategories as sub', 'sub.category_id = cate.cid'); 
        $this->db->join('childcategories as child', 'child.subcategory_id = sub.id');
        $this->db->like('cate.name', $keyword);
        $this->db->or_like('sub.name', $keyword);
        $this->db->or_like('child.name', $keyword);
        $query = $this->db->get();
        return $query->result();
    }

    // Method to get the list of products based on category links
    public function getPrdctlist($link = null, $link1 = null, $link2 = null) {
        $this->db->select('*');  
        $this->db->from('products');
        if (!is_null($link)) {
            $this->db->where('category', $link);
        }
        if (!is_null($link1)) {
            $this->db->where('subcategory', $link1);
        }
        if (!is_null($link2)) {
            $this->db->where('childcategory', $link2);
        }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    // Method to get paginated records
    public function get_records($limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->get("products");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    // Method to get total records count
    public function get_total_records() {
        return $this->db->count_all('products');
    }
}

?>
