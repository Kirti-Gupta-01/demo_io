<?php 
	
	class Cart_model extends CI_Model {
		public function __construct() {
			parent::__construct();
			$this->load->database();
		}

		// Method to add a product to the cart
		public function addProductToCart($userId, $productId) {
			$data = array(
				'user_id' => $userId,
				'product_id' => $productId,
				'quantity' => 1
			);

			return $this->db->insert('Cart', $data);
		}

	}
	
?>
