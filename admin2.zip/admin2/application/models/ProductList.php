
<?php
class ProductList extends CI_Model {
	 
   public function  getPrdctlist() {
        
        return $this->db->get('products')->result();
		}  
	public function deletePrdctlist($id){
		$this->db->where('pid',$id);
		$this->db->delete('products');
		  return $this->db->affected_rows();
	}
	
	public function  getchildCatglist() {
        		   
    $this->db->select('cg.cid,cg.name as cate , sc.id,sc.name as subg ,cc.id ,cc.name as childg ');
    $this->db->from('childcategories as cc');
    $this->db->join('subcategories as sc', 'sc.id = cc.subcategory_id'); 
    $this->db->join('categories as cg', ' cg.cid = sc.category_id ');

    $query = $this->db->get();
	
    if ($query) {
		
      return  $result = $query->result();
      

    } else {
        
        return false; 
    }
		}
// json ===================================
	public function getSubcategoriesbyid($categoryId){
	$this->db->select('name,id');
	$this->db->from('subcategories');
	$this->db->where('category_id',$categoryId);
	$this->db->where('active_inactive','on');
	$query = $this->db->get();
	
    if ($query) {
      return  $result = $query->result();
      
    } else {
        
        return false; 
    }
}	
	public function getchildcategoriesbyid($subcategoryId){
		$this->db->select('name,id');
		$this->db->from('childcategories');
		$this->db->where('subcategory_id',$subcategoryId);
		$this->db->where('active_inactive','on');
		$query = $this->db->get();
	
		if ($query) {
			return  $result = $query->result();
      
		} else {
        
			return false; 
		}
}	

//==================================================================
	public function getCategory() {
        
        return $this->db->get('categories')->result();
		}
		
	public function update_product($pid ,$data) {
        $this->db->where('pid', $pid);
        $this->db->update('products', $data);
		return $this->db->affected_rows();
    }
    
	
	public function getProductById($id) {
    
    $this->db->select('prd.pid, prd.pname as prdname ,prd.image,prd.price,prd.descreption,prd.qty,prd.size, cc.cid, cc.name as ccname, subcg.id as subcg_id, subcg.name as sbname, childcg.id as childcg_id, childcg.name as childcg');
    
   
    $this->db->from('products as prd');
    $this->db->join('categories as cc', 'cc.cid = prd.category', 'left');
    $this->db->join('subcategories as subcg', 'subcg.id = prd.subcategory', 'left');
    $this->db->join('childcategories as childcg', 'childcg.id = prd.childcategory', 'left');
    
   
    $this->db->where('prd.pid', $id);
    
   
    $query = $this->db->get();

   
    if ($query && $query->num_rows() > 0) {
        return $query->result(); 
    } else {
        return false; 
    }


}

	//===========================================================
	
	public function getCategoryById($cid) {
		
		$this->db->where('category', $cid);
        $query=$this->db->get('products');
		return $query->result();
      
  
}

public function getProductDetailsById($pid){
		$this->db->where('pid', $pid);
        $query=$this->db->get('products');
		return $query->result();
}

public function getReviewList($pid){
		$this->db->where('product_id', $pid);
        $query=$this->db->get('review');
		return $query->result();
}
//=======================================================

	public function decrease_stock($pid, $qty) {
        // Check current stock
        $query = $this->db->get_where('products', array('pid' => $pid));
        $product = $query->row();

        if ($product && $product->stock > $qty) {
            // Enough stock available
            $new_stock = $product->stock - $qty;
            $this->db->where('pid', $pid);
            $this->db->update('products', array('stock' => $new_stock));
            return TRUE;
        } else {
            
            return FALSE;
        }
    }
	
   } 
  //========================= 
   
?>
