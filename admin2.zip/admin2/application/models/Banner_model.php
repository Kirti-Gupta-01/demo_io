<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
class Banner_model extends CI_Model
{
	function __construct()
		{	
			parent::__construct();
			$this->load->database();	
		}
	public function insert_data($banner_data)
			{	
	$data=$this->db->insert('banner', $banner_data); 
	//print_r($data);die;
			}
	public function  getBannerlist() {
        
        return $this->db->get('banner')->result();
		}
	public function deletebannerlist($id){
		$this->db->where('bid',$id);
		$this->db->delete('banner');
		  return $this->db->affected_rows();
	}	
	
	public function  getcartlist() {
        
        return $this->db->get('cartitems')->result();
		}
	
}
?>

