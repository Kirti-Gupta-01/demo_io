<?php
class Ordermodel extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function addorder($orderData) {
		
		$this->load->database();
		return $this->db->insert('billing_details' , $orderData); 
		
       
    }
	public function getdata() {
	$this->load->database();	
	$query = $this->db->get('billing_details');
			return $query->result();
		
       
    }
}
?>
