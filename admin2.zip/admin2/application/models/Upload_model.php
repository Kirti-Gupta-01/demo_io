<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
class Upload_model extends CI_Model
{

	function __construct()
		{	
			parent::__construct();
			$this->load->database();	
		}
		public function insertdata($post)
			{
				
		$this->load->database();
		return $this->db->insert('products' , $post); 
		//print_r($data);die;
			}
		
	
	
}
?>

