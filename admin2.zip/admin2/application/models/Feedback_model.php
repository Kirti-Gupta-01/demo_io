<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
class Feedback_model extends CI_Model
{

	function __construct()
		{	
			parent::__construct();
			$this->load->database();	
		}
		public function insertdata($data)
			{
		return $this->db->insert('feedback',$data); 
		//print_r($data);die;
			}
		public function getdata()
			{
		$query=$this->db->get('feedback'); 
		return $query->result();
		//print_r($data);die;
			}
		
	
	
}
?>

