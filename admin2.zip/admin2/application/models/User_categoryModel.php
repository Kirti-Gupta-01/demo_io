
<?php
class User_CategoryModel extends CI_Model {
  
   public function  getCatglist() {
        
        return $this->db->get('categories')->result();
		}
		
	/*public function  getsubCatglist() {
        
        return $this->db->get('subcategories')->result();
		}
		
	public function  getchildCatglist() {
        
        return $this->db->get('childcategories')->result();
		}*/
    
   } 
   
?>
