<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
class Home_model extends CI_Model
{
	function __construct(){	
			parent::__construct();	
			 $this->load->database();
		}
	public function getdata() {
        $query = $this->db->get('categories');
        return $query->result();
    }	
	public function getdatasub($cid = NULL){
    if ($cid === NULL) {
        $query = $this->db->get('subcategories');
    } else {
        $query = $this->db->get_where('subcategories', array('category_id' => $cid));
    }
    return $query->result();
}

	public function getdata_prdct() {
        $query = $this->db->limit(12)->get('products');
        return $query->result();
    }	
	
	public function save_rating($reviewData) {
        $query = $this->db->insert('review',$reviewData);
		//echo $this->db->last_query();die;
        return $this->db->insert_id();
    }	
public function getdata_review() {
  
    $this->load->database();
    $this->db->select('pds.pid, pds.pname as pdsname, pds.image, pds.descreption, rw.id, rw.name as rwname, rw.email, rw.review, rw.star, rw.date');
    $this->db->from('review as rw');
    $this->db->join('products as pds', 'pds.pid = rw.product_id', 'left');
    $query = $this->db->get();

    // echo $this->db->last_query(); die;

   
    return $query->result();
}

public function saveCartData($data)
    {
        // Assuming 'cart_table' is the name of your table for storing cart data.
        return $this->db->insert('cartitems', $data);
    }

}

/* 
public function getdata_cartitem() {
  
    $this->load->database();
    $this->db->select('pds.pid, pds.pname as pdsname, pds.image, pds.descreption, rw.id, rw.name as rwname, rw.email, rw.review, rw.star, rw.date');
    $this->db->from('review as rw');
    $this->db->join('products as pds', 'pds.pid = rw.product_id', 'left');
    $query = $this->db->get();

    // echo $this->db->last_query(); die;

   
    return $query->result();
}

public function save_rating($reviewData) {
        $query = $this->db->insert('review',$reviewData);
		
        return $this->db->insert_id();
    }	*/
?>

