
<?php
class CategoryModel extends CI_Model {
	
	public function addCategory($data) {
		
		return $this->db->insert('categories',$data);  
		}
	
	public function getCategories() {
        
        return $this->db->get('categories')->result();
		}
    
	public function addsubCategory($data) {

		return $this->db->insert('subcategories',$data); 
        
    }
	public function get_Categories() {
        
        return $this->db->get('categories')->result();
	}
	public function getSubcategories() {
       
        return $this->db->get('subcategories')->result();
    }
	
    
	public function addchildCategory($data1) {

	 $this->db->insert('childcategories',$data1); 
	 return $this->db->insert_id();
        
    }
	public function getchildcategories() {
       
        return $this->db->get('childcategories')->result();
    }
	
  
   //listing of the categories===============================
  
   public function  getCatglist() {
        
        return $this->db->get('categories')->result();
		}
		
	public function  getsubCatglist() {
        
       // return $this->db->get('subcategories')->result();
		
		
		$this->db->select('sb.id,sb.name, cg.name as catname ,cg.active_inactive');
		$this->db->from('subcategories as sb');
		$this->db->join('categories as cg', 'cg.cid = sb.category_id');
  
    $query = $this->db->get();

    
    if ($query) {
       return $result = $query->result();
        
    } else {
       
return false; 
   }
		
		
		
		}
		
	public function  getchildCatglist() {
        
       // return $this->db->get('childcategories')->result();
		   
    $this->db->select('cg.cid,cg.name , sc.id,sc.name as subg ,cc.id ,cc.name as childg ,cg.active_inactive');
    $this->db->from('childcategories as cc');
    $this->db->join('subcategories as sc', 'sc.id = cc.subcategory_id'); 
    $this->db->join('categories as cg', ' cg.cid = sc.category_id ');

    $query = $this->db->get();
	
    if ($query) {
		
      return  $result = $query->result();
      

    } else {
        
        return false; 
    }
		}
		
public function getSubcategoriesbyid($categoryId){
	$this->db->select('name,id');
	$this->db->from('subcategories');
	$this->db->where('category_id',$categoryId);
	$this->db->where('active_inactive','on');
	$query = $this->db->get();
	
    if ($query) {
      return  $result = $query->result();
      
    } else {
        
        return false; 
    }
}	
    
   } 
   
?>
