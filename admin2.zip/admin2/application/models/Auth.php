<?php

class Auth extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		
	}
	public function insertdata($table,$data)
	{
		
		$this->load->database();
		return $this->db->insert($table , $data); 
		//print_r($data);die;
	}
	public function insertdata2($table,$data1)
	{
		
		$this->load->database();
		return $this->db->insert($table , $data1); 
		//print_r($data);die;
	}
	public function getinfo($eml ,$pwd)
	{
			$this->load->database();			
			$this->db->where('email', $eml);
			$this->db->where('password', $pwd);
			$query = $this->db->get('register');
		//print_r($query);
		return $query->result();
	}
	public function insertlogin($user)
	{
			//print_r($user);die;
			foreach($user as $k => $r){
			
				//$login_id = $r->login_id;
				$username = $r->email;
				$password = $r->password;
			
		}	
		$row = array(
		 
               'email'     => $username,
               'password'   => $password,
               'rid'    => 'TRUE',
               //'ipaddress' => $login_id,
            );	
			
			//print_r($row);die;
		$this->load->database();
		return $this->db->insert('login_user' , $row); 
		//print_r($data);die;
		}
	public function getdata($unm ,$pwd)
	{
			$this->db->where('username', $unm);
			$this->db->where('password', $pwd);
			$query = $this->db->get('login');
			return $query->result();
	}
	



}
?>