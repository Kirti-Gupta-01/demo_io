<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	function __construct() {
        parent::__construct();
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->model('Home_model');
		$this->load->model('Banner_model');
		$this->load->model('ProductList');
		$data['banner'] = $this->Banner_model->getBannerlist();
		$this->load->vars($data);
    }

	public function index()
	{
		$data['product_list'] = $this->Home_model->getdata_prdct();
		//echo "<pre>";print_r($data);	die();
		$data['banner'] = $this->Banner_model->getBannerlist();
		//print_r($data);die;
		$data['category'] = $this->Home_model->getdata();
		$data['subcategory'] = $this->Home_model->getdatasub();
		$this->load->view('frontend/home',$data);
	}
	public function category($cid){
		
    $data1['subcategory'] = $this->Home_model->getdatasub($cid);
    $data1['category'] = $this->Home_model->getdata();
    $data1['categoryData'] = $this->ProductList->getCategoryById($cid);

    $this->load->view('frontend/home', $data1);
}

	 public function product_list() {
		$data['product_list'] = $this->Home_model->getdata_prdct();
		//echo "<pre>";print_r($data);	die();
        
        $this->load->view('frontend/home', $data);
    }
public function getSubcategories() {
    $categoryId = $this->input->get('categoryId');
    $subcategories = $this->Home_model->getdatasub($categoryId);
    
    $links = '';
    foreach ($subcategories as $sub) {
        $links .= '<a href="' . base_url('Home/subCategory/' . $sub->id) . '" class="dropdown-item">' . $sub->name . '</a>';
    }
    
    echo $links;
}
public function contact(){
	$this->load->view('frontend/contactus');
}

public function review() {
	
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    $this->form_validation->set_rules('product_id', 'Product ID', 'required|integer');
    $this->form_validation->set_rules('rating', 'Rating', 'required|integer|greater_than[0]|less_than[6]');
    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('review_text', 'Review', 'required');

    $reviewData = array(
        'product_id' => $this->input->post('product_id'),
        'star' => $this->input->post('rating'),
        'name' => $this->input->post('name'),
        'email' => $this->input->post('email'),
        'review' => $this->input->post('review_text')
    );

    if ($this->form_validation->run() == FALSE) {
        $data['reviewData'] = $reviewData;
        $this->load->view('frontend/shop2', $data); // Assuming 'frontend/review_form' is your form view
    } else {
        log_message('debug', 'Received data: ' . print_r($reviewData, true));
        
        $result = $this->Home_model->save_rating($reviewData);

        if($result) {
            $data['message'] = 'Rating successfully saved.';
            $data['status'] = 'success';
            $data['reviewData'] = $reviewData;
			echo json_encode($data);
            // Assuming 'frontend/review_success' is your success view
        } else {
            // Handle failure case
            $data['message'] = 'Failed to save rating.';
            $data['status'] = 'error';
			echo json_encode($data);  
        }
    }

	}
	public function review_data() {

    $reviewData = $this->Home_model->getdata_review();
    
    $response = [];
    
  
    if (!empty($reviewData)) {
        $response = [
            'status' => 'success', 
            'data' => $reviewData
        ];
    } else {
        
        $response = [
            'status' => 'error',
            'message' => 'No review data found.' 
        ];
    }
    $this->output ->set_output(json_encode($response));
         //->set_content_type('application/json')
        
}

}

?>