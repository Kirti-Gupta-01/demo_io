<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {
	
	public function __construct() {
        parent::__construct();
        $this->load->model('Search_model');
        $this->load->library('pagination');
        $this->load->model('ProductList');  
        $this->load->model('CategoryModel');  
    }
   public function search_prdct(){
    $keyword = $this->input->post('keyword');
    $results = $this->Search_model->search_products($keyword);
    if(!empty($results)){
        foreach($results as $val){
         
            echo '<p><a href="'.base_url('search/getSearchlist?link='.$val->cid).'">'.$val->cname.'</a></p>';
            if (!empty($val->subname)) { 
                echo '<p><a href="'.base_url('search/getSearchlist?link1='.$val->subid).'"> '.$val->subname.'</a></p>';
            }
            if (!empty($val->childname)) { 
                echo '<p><a href="'.base_url('search/getSearchlist?link2='.$val->childid).'">'.$val->childname.'</a></p>';
            }
        } 
		}else{
			echo '<p>NO Record Found...</p>';
		}
	}
	//print_r($results);
    //echo json_encode($results); getSearchlist
	
	public function getSearchlist() {
		
	
	
	
    $link = $this->input->get('link');
    $link1 = $this->input->get('link1');
    $link2 = $this->input->get('link2');

    $data['products'] = $this->Search_model->getPrdctlist($link ,$link1 ,$link2);
	
	$data['title']="list Category";
	$data['categories'] = $this->CategoryModel->getCatglist();
	
	$this->load->view('frontend/shop', $data);
   
}
public function pagination($keyword = null) {
        // Fetch keyword from GET or POST request
        if ($keyword == null) {
            $keyword = $this->input->get('keyword');
        }

        // Pagination configuration
        $config['base_url'] = base_url('search/getSearchlist' . $keyword);
        $config['total_rows'] = $this->Search_model->get_total_records();
        $config['per_page'] = 10; // Adjust as needed
        $config['uri_segment'] = 3;
        $config['use_page_numbers'] = TRUE;

        $this->pagination->initialize($config);

        // Calculate offset
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 1;
        $offset = ($page - 1) * $config['per_page'];

        // Fetch paginated data
        $data['results'] = $this->Search_model->get_records($config['per_page'], $offset);
        $data['pagination'] = $this->pagination->create_links();

        // Load view
        $this->load->view('frontend/shop', $data);
    }

}
?>

