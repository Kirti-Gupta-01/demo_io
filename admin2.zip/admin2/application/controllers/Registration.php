<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {
	

	public function index()
	{
		
		$this->load->view('main');
		
	}
	public function register(){
		
		$this->load->view('frontend/register');
			
	}
	public function login(){
		
		$this->load->view('frontend/login');
			
	}
	public function register_user()
	{
		$data=array(
			'name' => $this->input->post('name'),
			'sname' => $this->input->post('sname'),
			'tname' => $this->input->post('tname'),
			'mobile' => $this->input->post('mob'),
			'dob' => $this->input->post('dob'),
			'gender' => $this->input->post('gender'),
			'address' => $this->input->post('add'),
			'flag' => 'TRUE',
		 );	
		 //print_r($data);die;
			$this->load->model('Auth');
			$this->Auth->insertdata('registerinfo',$data);		
			$id=$this->db->insert_id();
			//print_r($id);
			
			if(!empty($id)){		
				$data1=array(
					'rid' => $id,
					'email' => $this->input->post('eml'),
					//'password' =>hash('sha256',$this->input->post('pwd')), 
					'password' =>$this->input->post('pwd'), 
					);
				$this->load->model('Auth');
				$this->Auth->insertdata2('register',$data1);
				 redirect('Registration/login');
					exit; 	
				}
	}
	public function Auths(){
				$eml = $this->input->post('email');
				$pwd = $this->input->post('pwd');
				//print_r($eml);
				//print_r($pwd);die;
						$this->load->model('Auth');
						$user= $this->Auth->getinfo($eml ,$pwd);
				//echo "<pre>";
				//print_r($user);die;
						
		if (!empty($user)) {
    $this->load->library('session');
    // Set user data in session without the password
    $this->session->set_userdata(array(
        'id' => $user[0]->id,
        'email' => $user[0]->email,
        'password' => $user[0]->password,
		
    ));
     $this->Auth->insertlogin($user);
    redirect(base_url());
	
    exit; 
} else {
	 $this->session->set_flashdata('login_error', 'Invalid name or password');

    redirect('Registration/login');
   
    exit; 
}
	}
	public function logout()
	{
		if(!empty($this->session->userdata)){
		$this->session->sess_destroy();
		redirect(base_url());
		}else{
			redirect('Registration/login');
		}
	}
	
}
