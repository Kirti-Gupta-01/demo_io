<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testmonial extends CI_Controller {
	 public function __construct() {
        parent::__construct();
        $this->load->model('Feedback_model');    
    }
	public function index()
		{
	$data['feedback']= $this->Feedback_model->getdata();	
			//echo "<pre>";print_r($data1);
	
			$this->load->view('frontend/testmonial',$data);	
		}	
		
	public function feedback()
		{
			//echo "hey hey you";
			$this->load->view('frontend/feedback ');	
		}
	public function feedbackdata()
		{
			$data=array(
			'Name' => $this->input->post('name'),
			'Email' => $this->input->post('email'),
			'Rating' => $this->input->post('rating'),
			'Feedback' => $this->input->post('feedback'),
		 );		
		// print_r($data);
		
		
	$this->Feedback_model->insertdata($data);	
	
			}
	

	
}
?>
