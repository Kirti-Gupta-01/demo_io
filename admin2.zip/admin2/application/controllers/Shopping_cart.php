<?php 

	class Shopping_cart extends CI_Controller {

		public function __construct() {
			parent::__construct();
			$this->load->model('Cart_model');
			// Ensure the user is logged in
			if (!$this->session->userdata('user_id')) {
				redirect('login');
			}
		}

		public function add_to_cart($productId) {
			
			{	
		if (!empty($this->session->userdata('email'))) {
    $username = $this->session->userdata('email');
    $user_id = $this->session->userdata('user_id');
    //print_r($username);
    //die;
} 
    $data = array{
		'Username'=>$username,
		'UserID' => $user_id,
		
	};			
			
			$productExists = $this->Product_model->checkProductExists($productId);

			
			
			

			redirect('products');
		}
	}
?>
