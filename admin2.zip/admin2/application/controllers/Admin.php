<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	

	public function index()
	{
		$this->load->view('login');
	}
	public function auth()
	{
		$unm = $this->input->post('unm');
		$pwd = $this->input->post('pwd');
		
		$this->load->model('Auth');
		$user = $this->Auth->getdata($unm, $pwd);
   // $this->load->view('main');

if(!empty($user)) {
    $this->load->library('session');
    
    // Store user ID and username in the session
		$this->session->set_userdata(array('id' => $user[0]->id, 'username' => $user[0]->username,'name'=>$user[0]->name));
redirect(base_url('dashboard'));
} else {
    $this->session->set_flashdata('msg','<span class="text-danger">User Name or Password is Incorrect</span>');
    redirect(base_url());
}

		
	}
	
	public function logout()
	{
		$user_data = $this->session->all_userdata();
        foreach ($user_data as $key => $value) {
            if ($key != 'session_id') {
                $this->session->unset_userdata($key);
            }
        }
		$this->session->sess_destroy();
		redirect('admin');
	}
	
}
