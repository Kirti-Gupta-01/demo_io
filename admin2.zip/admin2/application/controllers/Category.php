<?php 
class Category extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('CategoryModel');    
    }
	public function addCatg(){
		$data['title']="Add Category";
		$this->load->view('category/addcatg');
}
	public function saveCategory(){
		$data=array(
			'name' => $this->input->post('catg'),
			'active_inactive' => $this->input->post('active'),
		 );	
		 $this->CategoryModel->addCategory($data);		
	}
	
	//add sub categories
	
	public function addsubCatg(){
		
		$data['title']="Add Category";
		$data['categories'] = $this->CategoryModel->getCategories();
		$this->load->view('category/addsubcatg',$data);
	
		}
	public function savesubCategory(){
		
		$data=array(
			'category_id'=>$this->input->post('category'),
			'name' => $this->input->post('catg'),
			'active_inactive' => $this->input->post('active'),
		 );	
		 $this->CategoryModel->addsubCategory($data);		
	}
	
	
	public function addchildCatg(){
		
		$data['title']="Add subCategory";
		$data['categories'] = $this->CategoryModel->get_Categories();
		$data['subcategories'] = $this->CategoryModel->getsubCategories();
		$this->load->view('category/addchildcatg',$data);
		$this->load->view('products/addProduct',$data);
	
		}
	public function savechildCategory(){
		
		$data1=array(
			
			'categ_id'=>$this->input->post('catg'),
			'subcategory_id'=>$this->input->post('category'),
			'name' => $this->input->post('name'),
			'active_inactive' => $this->input->post('active'),
		 );	
		 $res= $this->CategoryModel->addchildCategory($data1);
		 if(!empty($res)){
		 $this->session->set_flashdata('msg','<span class="text-success">Data saved successfully</span>');
		 }else{
			  $this->session->set_flashdata('msg','<span class="text-danger">Data not saved successfully</span>');
		 }
		 redirect(base_url('category/addchildCatg'));
		}
	
	
	
	// list of the categories
	
	
	
	
	public function listCatg(){
		
		$data['title']="list Category";
		$data['categories'] = $this->CategoryModel->getCatglist();
		$this->load->view('category/listcatg',$data);
	
	}
	public function listsub(){
		
		$data['title']="list subCategory";
		$data['categories'] = $this->CategoryModel->getsubCatglist();
		//echo "<pre>";print_r($data);die;
		$this->load->view('category/listsubcatg',$data);
	
	}
	public function listchildCatg(){
		
		$data['title']="list childCategory";
		$data['categories'] = $this->CategoryModel->getchildCatglist();
		//echo "<pre>";print_r($data);die;
		$this->load->view('category/listchildcatg',$data);
	
	}
	
public function getSubcategories()
{
	$categoryId= $this->input->post('categoryId');
	$data['subcatgres'] = $this->CategoryModel->getSubcategoriesbyid($categoryId);
	echo json_encode($data);die;
}

  
}
?>