<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends CI_Controller {
	 public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'file'));
        
        $this->load->model('Banner_model'); // Load the model
    }

	public function index()
	{
		//echo "hello moto";
		$this->load->view('banner/addbanner');
		
	}

	public function banner_upd(){
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 2122317824;

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

       if ($this->upload->do_upload('image')) { 
	   
	   $data = $this->upload->data();
            $banner_data = array(
                'bname' =>  $this->input->post('bname'),
                'active_inactive' =>  $this->input->post('active'),
                'image' => base_url("uploads/" . $data['raw_name'] . $data['file_ext']),
            );
            //echo "<pre>";print_r($data);die;
            
            $res=$this->Banner_model->insert_data($banner_data);
		
				if(empty($res)){
					$this->session->set_flashdata('msg','<span class="text-success">Data saved successfully</span>');
				}else{
					$this->session->set_flashdata('msg','<span class="text-danger">Data not saved successfully</span>');
				}
				redirect(base_url('Banner'));
       } else {
            $error = $this->upload->display_errors();
            echo $error;
        }
		
    }
	public function listbanner(){
	 	$data['title']="list Banner";
		$data['banner'] = $this->Banner_model->getBannerlist();
		//print_r($data);die;
		$this->load->view('banner/listBanner',$data);	
	}
	public function deletebanner(){
			$id=$this->input->get('bid');
			$res=$this->Banner_model->deletebannerlist($id);
			if(!empty($res)){
					$this->session->set_flashdata('msg','<span class="text-success">Data delete successfully</span>');
				}else{
					$this->session->set_flashdata('msg','<span class="text-danger">Data not delete successfully</span>');
				}
				redirect(base_url('Banner/listBanner'));
	}
	public function update_banner(){
	 	$data['title']="update Banner";
		$data['banner'] = $this->Banner_model->getBannerlist();
		//print_r($data);die;
		//$this->load->view('frontend/home',$data);
		
	
		}
	
	public function cartlist(){
	 	$data['title']="list cart";
		$data['cartdata'] = $this->Banner_model->getcartlist();
		//echo "<pre>";print_r($data);die;
		$this->load->view('cart_product/listcart',$data);	
	}
}
