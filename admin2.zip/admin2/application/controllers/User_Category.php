<?php 
// list of the categories
class User_Category extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('User_CategoryModel');    
    }
	public function listCatg(){
		$data['title']="list Category";
		$data['result'] = $this->User_CategoryModel->getCatglist();
		//print_r($data);die;
		//$this->load->view('sidebar',$data);
		}

    
}
?>