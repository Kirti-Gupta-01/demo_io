<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Place_order extends CI_Controller {
	
	public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->form_validation->set_message('check_custom_name', 'The {field} field must contain only letters.');
        $this->form_validation->set_message('validate_mobile', 'The {field} field must contain a valid mobile number.');
    }


    public function index() {
        $this->load->library('form_validation');
       $this->form_validation->set_rules('name', 'Name', 'required|trim|regex_match[/^[a-zA-Z ]+$/]', ['regex_match' => 'The Name field may only contain alphabetical characters.']);
        $this->form_validation->set_rules('lname', 'Last Name', 'required|trim|regex_match[/^[a-zA-Z ]+$/]', ['regex_match' => 'The Last Name field may only contain alphabetical characters.']);
        $this->form_validation->set_rules('mob', 'Mobile', 'required|trim|callback_validate_mobile');
        $this->form_validation->set_rules('eml', 'Email Address', 'required|trim|valid_email');
        $this->form_validation->set_rules('add', 'Address', 'required|trim');
        $this->form_validation->set_rules('t_c', 'Town/City', 'required|trim');
        $this->form_validation->set_rules('cont', 'Country', 'required|trim');
        $this->form_validation->set_rules('pin', 'Postcode/ZIP', 'required|trim');
        $this->form_validation->set_rules('Payments', 'Payments Method', 'required|trim'); 
        
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('cart_error', '<span class="cart_error">Kindly fill all  required field .</span>');
            redirect('cart/checkout');
        } else {
            $email = $this->input->post('eml');
            
            if($this->session->userdata('email') == $email) {
                // Prepare data for insertion
                $data = array(
                    'first_name' => $this->input->post('name'),
                    'last_name' => $this->input->post('lname'),
                    'mobile' => $this->input->post('mob'),
                    'email_address' => $this->input->post('eml'),
                    'address' => $this->input->post('add'),
                    'town_city' => $this->input->post('t_c'),
                    'country' => $this->input->post('cont'),
                    'postcode_zip' => $this->input->post('pin'),
                    'order_notes' => $this->input->post('text'), 
                    'Check_Payments' => $this->input->post('Payments'),
                    'Cod' => $this->input->post('Payments'),
                    'Paypal' => $this->input->post('Payments')
                );
                // Add the order
                $this->load->model('Ordermodel');
                $order = $this->Ordermodel->addorder($data);
                $this->session->set_flashdata('cart_set', '<span class="cart_error">Successfully placed order.</span>');
                redirect('cart/checkout');
            } else {
                // Set a different flash message for cases where emails do not match
                $this->session->set_flashdata('cart_error', '<span class="cart_error">The email address does not match the logged-in user.</span>');
                redirect('cart/checkout');
            }
        }
    }
}
