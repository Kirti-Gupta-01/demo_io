<?php
//error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

	class Cart extends CI_Controller{
		
		 public function __construct() {
			parent::__construct();
			
			$this->load->library('cart');		
		}	
	public function index()
		{				
			$data=$this->cart->contents();
			//echo "<pre>";print_r($data);
			$this->load->view('frontend/cart',$data);
		}
		
	public function update_quantity() {
		
    $row_id = $this->input->post('rowId');
    $quantity =$this->input->post('quantity'); // Ensure quantity is treated as an integer

    $data = array(
        'rowid' => $row_id,
        'qty'   => $quantity
    );

    $updateStatus = $this->cart->update($data);

    if ($updateStatus) {
        
        $cart = $this->cart->contents();
        $updatedItem = isset($cart[$row_id]) ? $cart[$row_id] : false;

        if ($updatedItem) {
            $new_total = $this->calculateTotal(); // Make sure this method exists and calculates total correctly
            echo json_encode(array(
                'status' => 'success',
                'new_quantity' => $updatedItem['qty'],
                'new_subtotal' => $updatedItem['subtotal'],
                'new_total' => $new_total
            ));
        } else {
            echo json_encode(array('status' => 'error', 'message' => 'Failed to retrieve updated item details.'));
        }
    } else {
        // Failed to update the cart item
        echo json_encode(array('status' => 'error', 'message' => 'Failed to update the cart item.'));
    }
}
	private function calculateTotal() {
		$new_total = 0;

		foreach ($this->cart->contents() as $item) {
			$new_total += $item['subtotal'];
		}

		return $new_total;
	}
	private function calculateTotals() {
        $amount = 0;
        foreach ($this->cart->contents() as $item) {
            $amount += $item['subtotal'];
        }

        // Calculate GST
        $gstRate = 18;
        $gstAmount = ($amount * $gstRate) / 100;
        $totalAmount = $amount + $gstAmount;

        return $totalAmount;
    }
	public function removeItem($rowid)
	{				
			$data=$this->cart->remove($rowid);
			redirect('Cart');
	}

public function checkout()
		{				
			if(!empty($this->session->userdata('email'))){
				$this->load->view('frontend/checkout');
				
			 }	
			 else{ 
				$this->session->set_flashdata('msg','<span class="text-danger">kindly login first</span>');
				$this->load->view('frontend/login'); 	
			 }
	
		}

}
?>
