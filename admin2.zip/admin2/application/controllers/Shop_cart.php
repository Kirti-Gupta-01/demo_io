<?php
//error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

	class Shop_cart extends CI_Controller{
		
		 public function __construct() {
			parent::__construct();
		//$this->load->model('productmodel');
        $this->load->library('cart');
        $this->load->model('Home_model');
        $this->load->helper('url');	
		}	

    public function insertcart()
    {
        if (!empty($this->session->userdata('email'))) {
            $id = $this->input->post('pid');
            $query = $this->db->query("SELECT * FROM products WHERE pid = ?", array($id))->row();

            if ($query) {
                $cartData = array(
                    'id'    => $query->pid,
                    'qty'   => 1, // Assuming a fixed quantity of 1 for simplicity.
                    'price' => $query->price,
                    'name'  => $query->pname,
                    'image' => $query->image,
                );

                // Insert product data into the cart.
                $this->cart->insert($cartData);

                $username = $this->session->userdata('email');
                $user_id = $this->session->userdata('id'); 

                $dbData = array(
                    'Username'  => $username,
                    'UserID'    => $user_id,
                    'ProductID' => $query->pid,
                    'name'=> $query->pname,
     
                    'Image'     => $query->image,
                );

                $this->Home_model->saveCartData($dbData);

                redirect('Cart');
            } else {
                $this->session->set_flashdata('msg', '<span class="text-danger">Product not found.</span>');
                redirect('ProductNotFound'); // Adjust to your routing
            }
        } else {
            $this->session->set_flashdata('msg', '<span class="text-danger">Kindly log in first.</span>');
            $this->load->view('frontend/login');
        }
    }
}



?>
