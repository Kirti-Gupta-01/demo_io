<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Home_model');
        $this->load->model('Banner_model');
        $this->load->model('ProductList');
        $this->load->model('Ordermodel');
    }
	
    public function category() {
        // Assuming `getdata` is a method in `Home_model` that fetches category data
        $data['category'] = $this->Home_model->getdata();
       
        $this->load->view('frontend/home', $data);
    }

    public function details($pid) {
        $data['product_list'] = $this->Home_model->getdata_prdct();
        $data['productDetails'] = $this->ProductList->getProductDetailsById($pid);
        $data['reviewlist'] = $this->ProductList->getReviewList($pid);

        $this->load->view('frontend/shop2', $data);
    }

    public function process_sale() {
        
        $products = $this->input->post('products');
        foreach ($products as $product) {
            $pid = $product['id'];
            $qty = $product['qty'];

            if ($this->ProductList->decrease_stock($pid, $qty)) {
                echo "<h1>Order processed successfully.</h1>";
				$orderData = array(
            'first_name'     => $this->input->post('name'),
            'last_name'    => $this->input->post('lname'),
            'address'      => $this->input->post('add'),
            'town_city'      => $this->input->post('t_c'),
            'country'     => $this->input->post('cont'),
            'postcode_zip'      => $this->input->post('pin'),
            'mobile'      => $this->input->post('mob'),
            'email_address'      => $this->input->post('eml'),
            'order_notes'     => $this->input->post('text'),
            'Check_Payments' => $this->input->post('Payments'),
            'Cod' => $this->input->post('Payments'),
            'Paypal' => $this->input->post('Payments')
        );

        $this->Ordermodel->addorder($orderData);

            } else {
                echo "<h1>Not enough stock.</h1>";
            }
        }
    }
	public function getdetail() {
        
        $data['orderdetail'] = $this->Ordermodel->getdata();
       //print_r($data['orderdetail']);
        $this->load->view('frontend/userorderlist', $data);
    }
}
?>
