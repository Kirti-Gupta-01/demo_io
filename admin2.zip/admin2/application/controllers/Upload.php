<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'file'));
        $this->load->model('Upload_model'); // Load the model
        $this->load->model('CategoryModel','ctg'); // Load the model
        $this->load->model('ProductList'); // Load the model
    }

    public function index() {
		$data['catres']=$this->ctg->getCategories();
		//echo "<pre>";print_r($data);die;
        $this->load->view('products/addProduct',$data);
    }
	public function getsubcatg_name(){
		
	$categoryId= $this->input->post('categoryId');
	$data['subcatgres'] = $this->ProductList->getSubcategoriesbyid($categoryId);
	echo json_encode($data);die;
	
	}  
	public function getchildcatg_name(){
		
	$subcategoryId= $this->input->post('subcategoryId');
	$data['subcatgres'] = $this->ProductList->getchildcategoriesbyid($subcategoryId);
	echo json_encode($data);die;
	
	}  
	

    public function uploading(){
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 2122317824;

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

       if ($this->upload->do_upload('image')) { 
	   $data1['res'] = $this->ProductList->getchildCatglist();
	   $data = $this->upload->data();
            $product_data = array(
                'category' =>  $this->input->post('catg_name'),
                'subcategory' =>  $this->input->post('subcatg_name'),
                'childcategory' =>  $this->input->post('childcatg_name'),
                'pname' =>  $this->input->post('pname'),
                'price' =>  $this->input->post('price'),
                'qty' =>  $this->input->post('qty'),
                'image' => base_url("uploads/" . $data['raw_name'] . $data['file_ext']),
                'descreption' =>  $this->input->post('descreption'),
                'size' =>  $this->input->post('size')
            );
            //echo "<pre>";print_r($data1);die;
            
            $res=$this->Upload_model->insertdata($product_data);
			
				if(!empty($res)){
					$this->session->set_flashdata('msg','<span class="text-success">Data saved successfully</span>');
				}else{
					$this->session->set_flashdata('msg','<span class="text-danger">Data not saved successfully</span>');
				}
				redirect(base_url('Upload'));
			
            //echo 'File uploaded successfully!';
        } else {
            $error = $this->upload->display_errors();
            echo $error;
        }
		
    }
	public function listprdct(){
		echo $this->session->flashdata('msg');
	 	$data['title']="list Product";
		$data['products'] = $this->ProductList->getPrdctlist();
		//print_r($data);die;
		$this->load->view('Products/listProduct',$data);	
	}

	public function deleteproduct(){
			$id=$this->input->get('pid');
			$res=$this->ProductList->deletePrdctlist($id);
			if(!empty($res)){
					$this->session->set_flashdata('msg','<span class="text-success">Data delete successfully</span>');
				}else{
					$this->session->set_flashdata('msg','<span class="text-danger">Data not delete successfully</span>');
				}
				redirect(base_url('Upload/listprdct'));
	}
	public function editproduct() {
        $id = $this->input->get('pid');	
		//$data['title']="Edit Product";
        $data['res'] = $this->ProductList->getProductById($id);
		 $data['catres']=$this->ProductList->getCategory();
		//echo "<pre>" ;print_r($data);die;
     $this->load->view('products/editProduct',$data);
	

	}
	//
	public function updateProduct() {
	$imagefile="";
	$id = $this->input->post('hid');
	
	$imageh = $this->input->post('imageh');
	//print_r($imageh);die;
	if(!empty($_FILES['image']['name'])){
		$config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 2122317824;
        $this->load->library('upload', $config);
        $this->upload->initialize($config);

       if ($this->upload->do_upload('image')) { 
	   $data = $this->upload->data();
	   
		$imagefile=base_url("uploads/" . $data['raw_name'] . $data['file_ext']);
	   }
	}else{
		$imagefile=$imageh;
	}
        $data = array(
            'category' => $this->input->post('catg_name'),
            'subcategory' => $this->input->post('subcatg_name'),
            'childcategory' => $this->input->post('childcatg_name'),
            'pname' => $this->input->post('pname'),
            'image' => $imagefile,
            'descreption' => $this->input->post('descreption'),
            'price' => $this->input->post('price'),
            'qty' => $this->input->post('qty'),
            'size' => $this->input->post('size'),
        );
        $this->ProductList->update_product($id ,$data);
		
        redirect('Upload/listprdct');
    } 
	}
	

	
	

?>
