-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2024 at 08:53 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `bid` int(255) NOT NULL,
  `bname` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `active_inactive` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`bid`, `bname`, `image`, `active_inactive`) VALUES
(11, 'echo freindly', 'http://localhost/admin2/uploads/Screenshot_(27).png', 'on'),
(12, 'fruits', 'http://localhost/admin2/uploads/hero-img-1.png', 'on'),
(13, 'vegitables', 'http://localhost/admin2/uploads/hero-img-2.jpg', 'on'),
(14, 'next banner', 'http://localhost/admin2/uploads/images_(1)4.jpeg', 'on'),
(15, 'next banner', 'http://localhost/admin2/uploads/images_(5)3.jpeg', 'on'),
(16, 'banner', 'http://localhost/admin2/uploads/graphic-shirt-trendy-design-mockup3.jpg', 'on'),
(17, 'banner', 'http://localhost/admin2/uploads/32265652.jpg', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `billing_details`
--

CREATE TABLE `billing_details` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `town_city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `postcode_zip` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `order_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Check_Payments` varchar(255) DEFAULT NULL,
  `Cod` varchar(255) DEFAULT NULL,
  `Paypal` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billing_details`
--

INSERT INTO `billing_details` (`id`, `first_name`, `last_name`, `address`, `town_city`, `country`, `postcode_zip`, `mobile`, `email_address`, `order_notes`, `created_at`, `Check_Payments`, `Cod`, `Paypal`) VALUES
(6, 'Kirti', 'sahu', 'pratapgarh , U.P.', 'prayagraj', 'India', '211001', '08576085487', 'ria@gmail.com', 'ae', '2024-03-09 14:37:13', 'Delivery', 'Delivery', 'Delivery'),
(10, 'Kirti ', 'sahu', 'pratapgarh , U.P.', 'prayagraj', 'India', '211001', '8576085487', 'guptakirti@gmail.com', 'name', '2024-05-03 09:38:27', 'Delivery', 'Delivery', 'Delivery'),
(11, '', '', '', '', '', '', '', '', '', '2024-05-15 10:04:36', NULL, NULL, NULL),
(12, '', '', '', '', '', '', '', '', '', '2024-07-11 11:58:26', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `added_at` datetime DEFAULT current_timestamp(),
  `user_id` int(255) DEFAULT NULL,
  `pid` int(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cartitems`
--

CREATE TABLE `cartitems` (
  `CartItemID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `DateAdded` datetime DEFAULT current_timestamp(),
  `name` varchar(255) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cartitems`
--

INSERT INTO `cartitems` (`CartItemID`, `UserID`, `Username`, `ProductID`, `DateAdded`, `name`, `image`) VALUES
(3, 2, 'mahadev@gmail.com', 31, '2024-03-05 14:54:02', 'tops', 'http://localhost/admin2/uploads/g1.jpg'),
(9, 4, 'guptakirti@gmail.com', 28, '2024-03-06 10:46:05', 'sari', 'http://localhost/admin2/uploads/istockphoto-1270784869-1024x1024.jpg'),
(10, 4, 'guptakirti@gmail.com', 27, '2024-03-06 10:52:54', 'tops', 'http://localhost/admin2/uploads/g4.jpg'),
(11, 4, 'guptakirti@gmail.com', 31, '2024-03-06 12:29:45', 'tops', 'http://localhost/admin2/uploads/g1.jpg'),
(12, 4, 'guptakirti@gmail.com', 31, '2024-03-06 12:39:11', 'tops', 'http://localhost/admin2/uploads/g1.jpg'),
(15, 2, 'mahadev@gmail.com', 23, '2024-03-09 20:25:19', 'shirts', 'http://localhost/admin2/uploads/graphic-shirt-trendy-design-mockup1.jpg'),
(18, 2, 'mahadev@gmail.com', 27, '2024-03-11 21:41:48', 'tops', 'http://localhost/admin2/uploads/g4.jpg'),
(19, 2, 'mahadev@gmail.com', 28, '2024-03-12 11:01:30', 'sari', 'http://localhost/admin2/uploads/istockphoto-1270784869-1024x1024.jpg'),
(20, 2, 'mahadev@gmail.com', 30, '2024-05-01 15:17:14', 'tops', 'http://localhost/admin2/uploads/g2.jpg'),
(21, 2, 'mahadev@gmail.com', 26, '2024-05-01 15:22:50', 'sari', 'http://localhost/admin2/uploads/istockphoto-1441178475-1024x1024_(1).jpg'),
(22, 8, 'akanksha@gmail.com', 26, '2024-05-01 16:20:20', 'sari', 'http://localhost/admin2/uploads/istockphoto-1441178475-1024x1024_(1).jpg'),
(23, 2, 'mahadev@gmail.com', 31, '2024-05-02 12:33:32', 'tops', 'http://localhost/admin2/uploads/g1.jpg'),
(24, 2, 'mahadev@gmail.com', 27, '2024-05-02 15:47:30', 'tops', 'http://localhost/admin2/uploads/g4.jpg'),
(25, 1, 'mahadev@gmail.com', 30, '2024-05-02 16:10:37', 'tops', 'http://localhost/admin2/uploads/g2.jpg'),
(26, 2, 'mahadev@gmail.com', 31, '2024-05-03 10:26:34', 'tops', 'http://localhost/admin2/uploads/g1.jpg'),
(27, 2, 'mahadev@gmail.com', 28, '2024-05-03 10:28:01', 'sari', 'http://localhost/admin2/uploads/istockphoto-1270784869-1024x1024.jpg'),
(28, 2, 'mahadev@gmail.com', 32, '2024-05-03 11:29:13', 'pants', 'http://localhost/admin2/uploads/b11.png'),
(29, 2, 'mahadev@gmail.com', 34, '2024-05-03 11:44:01', 'pants', 'http://localhost/admin2/uploads/b41.png'),
(30, 2, 'mahadev@gmail.com', 34, '2024-05-03 11:50:09', 'pants', 'http://localhost/admin2/uploads/b41.png'),
(31, 2, 'mahadev@gmail.com', 36, '2024-05-03 14:25:46', 't-shirt', 'http://localhost/admin2/uploads/k4.jpg'),
(32, 2, 'mahadev@gmail.com', 31, '2024-05-03 14:53:48', 'tops', 'http://localhost/admin2/uploads/g1.jpg'),
(33, 2, 'mahadev@gmail.com', 28, '2024-05-03 14:54:36', 'sari', 'http://localhost/admin2/uploads/istockphoto-1270784869-1024x1024.jpg'),
(34, 2, 'mahadev@gmail.com', 25, '2024-05-03 14:54:50', 'sari', 'http://localhost/admin2/uploads/1000_F_94135525_YmKvyY9mmbvuDuHXil05gNtCtHp74m0S.jpg'),
(35, 2, 'mahadev@gmail.com', 27, '2024-05-15 15:34:19', 'tops', 'http://localhost/admin2/uploads/g4.jpg'),
(36, 2, 'mahadev@gmail.com', 30, '2024-05-15 16:34:01', 'tops', 'http://localhost/admin2/uploads/g2.jpg'),
(37, 2, 'mahadev@gmail.com', 30, '2024-05-15 16:34:14', 'tops', 'http://localhost/admin2/uploads/g2.jpg'),
(38, 2, 'mahadev@gmail.com', 26, '2024-07-11 17:27:00', 'sari', 'http://localhost/admin2/uploads/istockphoto-1441178475-1024x1024_(1).jpg'),
(39, 2, 'mahadev@gmail.com', 28, '2024-07-11 17:27:39', 'sari', 'http://localhost/admin2/uploads/istockphoto-1270784869-1024x1024.jpg'),
(40, 2, 'mahadev@gmail.com', 25, '2024-07-11 17:28:14', 'sari', 'http://localhost/admin2/uploads/1000_F_94135525_YmKvyY9mmbvuDuHXil05gNtCtHp74m0S.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` bigint(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `active_inactive` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `name`, `active_inactive`) VALUES
(1, 'stationery', 'on'),
(3, 'electronic', 'on'),
(6, 'dresses', 'on'),
(7, 'child', 'on'),
(9, 'funiture', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `categoris`
--

CREATE TABLE `categoris` (
  `cid` bigint(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `active/inactive` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `childcategories`
--

CREATE TABLE `childcategories` (
  `id` int(255) NOT NULL,
  `categ_id` text NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `active_inactive` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `childcategories`
--

INSERT INTO `childcategories` (`id`, `categ_id`, `subcategory_id`, `name`, `active_inactive`) VALUES
(1, '1', 103, 'Hindi', 'on'),
(2, '2', 107, 'Jacket', 'on'),
(3, '1', 103, 'Hindi', 'on'),
(4, '3', 105, 'oppo', 'on'),
(5, '6', 108, 'pants', 'on'),
(6, '6', 109, 't-shirt', 'on'),
(7, '6', 108, 'shirts 1', 'on'),
(8, '6', 109, 'sari', 'on'),
(9, '6', 109, 'tops', 'on'),
(11, '6', 110, 't shirs', 'on'),
(12, '3', 105, 'vivo', 'on'),
(13, '3', 105, 'micromax', 'on'),
(14, '3', 105, 'samsung', 'on'),
(15, '3', 111, 'hp', 'on'),
(16, '3', 111, 'lenovo', 'on'),
(17, '3', 111, 'apple', 'on'),
(18, '1', 103, 'ramayan', 'on'),
(19, '1', 103, 'bhagawat geeta', 'on'),
(20, '1', 103, 'rich dad and poor dad', 'on'),
(21, '7', 114, 'tops', 'on'),
(22, '7', 114, 'toys', 'on'),
(23, '7', 115, 'tshirt', 'on'),
(24, '7', 115, 'toys', 'on'),
(25, '3', 116, 'head phone', 'on'),
(26, '3', 116, 'head phones', 'on'),
(27, '3', 116, 'ear phones', 'on'),
(28, '3', 116, 'ear dopes', 'on'),
(29, '3', 112, 'digital camera', 'on'),
(30, '3', 112, 'camera', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Rating` text NOT NULL,
  `Feedback` text NOT NULL,
  `SubmissionDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fID`, `Name`, `Email`, `Rating`, `Feedback`, `SubmissionDate`) VALUES
(8, 'shashank', 'shashank1@gmail.com', 'Excellent', 'it\'s good', '2024-02-06 22:28:36'),
(9, 'Kirti ', 'sahukirti265@gmail.com', 'Excellent', 'it\'s good', '2024-02-06 22:29:02'),
(10, 'shashank', 'shashank1@gmail.com', 'Excellent', 'very very nice website', '2024-02-06 22:42:14'),
(11, 'aman gupta', 'aman@gmail.com', 'Excellent', 'Boats watches is very good watches in the worlds', '2024-02-12 12:22:51'),
(12, 'Kirti sahu', 'guptakirti0707@gmail.com', 'Very Good', 'nice products', '2024-02-21 14:21:36');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `name`, `image`) VALUES
(1, 'admin@gmail.com', '1234', 'Kirt Sahu', 'kirti.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login_user`
--

CREATE TABLE `login_user` (
  `user_id` int(11) NOT NULL,
  `rid` int(225) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(244) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_user`
--

INSERT INTO `login_user` (`user_id`, `rid`, `password`, `created_at`, `email`) VALUES
(6, 0, 'lucky123', '2024-02-26 07:13:08', 'mahadev@gmail.com'),
(8, 0, 'lucky123', '2024-02-26 07:14:46', 'mahadev@gmail.com'),
(9, 0, 'lucky123', '2024-02-26 07:16:27', 'mahadev@gmail.com'),
(10, 0, 'lucky123', '2024-02-26 07:20:09', 'mahadev@gmail.com'),
(11, 0, 'lucky123', '2024-02-26 07:20:20', 'mahadev@gmail.com'),
(12, 0, 'lucky123', '2024-02-26 08:46:09', 'mahadev@gmail.com'),
(13, 0, 'lucky123', '2024-02-26 08:46:37', 'mahadev@gmail.com'),
(14, 0, '987456321', '2024-02-26 09:02:10', 'guptakirti@gmail.com'),
(15, 0, '987456321', '2024-02-26 09:03:40', 'shashank01@gmail.com'),
(16, 0, '987456321', '2024-02-26 09:04:02', 'shashank01@gmail.com'),
(17, 0, '987456321', '2024-02-26 09:06:02', 'shashank01@gmail.com'),
(18, 0, '987456321', '2024-02-26 09:12:55', 'guptakirti@gmail.com'),
(19, 0, '987456321', '2024-02-26 09:13:16', 'guptakirti@gmail.com'),
(20, 0, '987456321', '2024-02-26 09:14:10', 'guptakirti@gmail.com'),
(21, 0, '987456321', '2024-02-26 09:17:34', 'guptakirti@gmail.com'),
(22, 0, 'lucky123', '2024-02-26 09:42:21', 'mahadev@gmail.com'),
(23, 0, 'lucky123', '2024-02-26 09:50:26', 'mahadev@gmail.com'),
(24, 0, 'lucky123', '2024-02-26 09:52:53', 'mahadev@gmail.com'),
(25, 0, '11110000', '2024-02-26 09:58:53', 'anchal@gmail.com'),
(26, 0, 'lucky123', '2024-02-27 05:08:56', 'mahadev@gmail.com'),
(27, 0, 'lucky123', '2024-02-27 05:20:58', 'mahadev@gmail.com'),
(28, 0, 'lucky123', '2024-02-27 05:31:15', 'mahadev@gmail.com'),
(29, 0, 'lucky123', '2024-02-27 05:31:31', 'mahadev@gmail.com'),
(30, 0, 'lucky123', '2024-02-28 05:01:20', 'mahadev@gmail.com'),
(31, 0, 'lucky123', '2024-02-28 05:02:09', 'mahadev@gmail.com'),
(32, 0, 'lucky123', '2024-02-28 08:28:22', 'mahadev@gmail.com'),
(33, 0, 'lucky123', '2024-03-05 06:59:42', 'mahadev@gmail.com'),
(34, 0, 'lucky123', '2024-03-05 09:44:49', 'mahadev@gmail.com'),
(35, 0, 'lucky123', '2024-03-05 10:26:56', 'mahadev@gmail.com'),
(36, 0, '987456321', '2024-03-06 05:15:51', 'guptakirti@gmail.com'),
(37, 0, 'lucky123', '2024-03-09 14:31:32', 'mahadev@gmail.com'),
(38, 0, 'lucky123', '2024-03-11 16:11:41', 'mahadev@gmail.com'),
(39, 0, 'lucky123', '2024-03-12 05:24:43', 'mahadev@gmail.com'),
(40, 0, 'lucky123', '2024-03-12 05:31:21', 'mahadev@gmail.com'),
(41, 0, 'lucky123', '2024-05-01 09:47:07', 'mahadev@gmail.com'),
(42, 0, 'kirti010101', '2024-05-01 10:36:34', 'akanksha@gmail.com'),
(43, 0, 'lucky123', '2024-05-02 07:03:24', 'mahadev@gmail.com'),
(44, 0, 'lucky123', '2024-05-02 10:17:24', 'mahadev@gmail.com'),
(45, 0, 'lucky123', '2024-05-03 04:56:27', 'mahadev@gmail.com'),
(46, 0, 'lucky123', '2024-05-03 08:53:43', 'mahadev@gmail.com'),
(47, 0, 'lucky123', '2024-05-10 09:18:07', 'mahadev@gmail.com'),
(48, 0, 'lucky123', '2024-05-15 10:04:11', 'mahadev@gmail.com'),
(49, 0, 'lucky123', '2024-05-15 11:53:35', 'mahadev@gmail.com'),
(50, 0, 'lucky123', '2024-07-11 11:56:52', 'mahadev@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(255) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `qty` int(255) NOT NULL,
  `image` text NOT NULL,
  `descreption` text NOT NULL,
  `size` int(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `childcategory` varchar(255) DEFAULT NULL,
  `Keywords` varchar(255) DEFAULT NULL,
  `viewport` varchar(255) DEFAULT NULL,
  `DateTime` datetime DEFAULT NULL,
  `stock` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `pname`, `price`, `qty`, `image`, `descreption`, `size`, `category`, `subcategory`, `childcategory`, `Keywords`, `viewport`, `DateTime`, `stock`) VALUES
(25, 'sari', 500, 1, 'http://localhost/admin2/uploads/1000_F_94135525_YmKvyY9mmbvuDuHXil05gNtCtHp74m0S.jpg', 'indian sARI', 6, '6', '109', '8', NULL, NULL, '2024-05-06 14:43:30', 4),
(26, 'sari', 600, 1, 'http://localhost/admin2/uploads/istockphoto-1441178475-1024x1024_(1).jpg', 'indian sARI', 6, '6', '109', '8', NULL, NULL, '2024-05-07 00:00:00', 0),
(27, 'tops', 500, 1, 'http://localhost/admin2/uploads/g4.jpg', 'beatifuls tops', 34, '6', '109', '9', NULL, NULL, '1900-01-02 00:00:00', 2),
(28, 'sari', 1000, 1, 'http://localhost/admin2/uploads/istockphoto-1270784869-1024x1024.jpg', 'indian sARI', 6, '6', '109', '8', NULL, NULL, '2024-05-08 00:00:00', 1),
(29, 'tops', 500, 1, 'http://localhost/admin2/uploads/g3.jpg', 'tops stylish', 32, '6', '109', '9', NULL, NULL, '2024-05-01 15:04:12', 5),
(30, 'tops', 600, 1, 'http://localhost/admin2/uploads/g2.jpg', 'tops fow girls/womens', 30, '6', '109', '9', NULL, NULL, '2024-05-07 11:02:23', 3),
(31, 'tops', 200, 1, 'http://localhost/admin2/uploads/g1.jpg', 'jils tops', 30, '6', '109', '9', NULL, NULL, '2024-05-01 00:00:00', 0),
(32, 'pants', 500, 1, 'http://localhost/admin2/uploads/b11.png', 'pants for men', 30, '6', '108', '5', NULL, NULL, NULL, 5),
(33, 'pants', 500, 1, 'http://localhost/admin2/uploads/b21.png', 'pants for men', 32, '6', '108', '5', NULL, NULL, NULL, 5),
(34, 'pants', 1000, 1, 'http://localhost/admin2/uploads/b41.png', 'pants for men', 30, '6', '108', '5', NULL, NULL, NULL, 5),
(35, 'pants', 500, 1, 'http://localhost/admin2/uploads/b31.png', 'pants for men', 34, '6', '108', '5', NULL, NULL, NULL, 5),
(36, 't-shirt', 500, 1, 'http://localhost/admin2/uploads/k4.jpg', 'tshirt', 30, '6', '109', '6', NULL, NULL, NULL, 5),
(37, 't-shirt', 500, 1, 'http://localhost/admin2/uploads/kirti.jpg', 'tshirt', 30, '6', '109', '6', NULL, NULL, NULL, 5),
(38, 't-shirt', 200, 1, 'http://localhost/admin2/uploads/p22.png', 't shirt for women', 34, '6', '109', '6', NULL, NULL, NULL, 5),
(39, 'pants', 500, 1, 'http://localhost/admin2/uploads/b12.png', 'pants for men', 32, '6', '108', '5', NULL, NULL, NULL, 5),
(40, 't-shirt', 200, 1, 'http://localhost/admin2/uploads/t1.jpg', 'tshirt for boy child ', 18, '6', '110', '11', NULL, NULL, NULL, 5),
(41, 't-shirt', 300, 1, 'http://localhost/admin2/uploads/t2.jpg', 'tshirt', 20, '6', '110', '11', NULL, NULL, NULL, 5),
(42, 't-shirt', 300, 1, 'http://localhost/admin2/uploads/t3.jpg', 'tshirt', 22, '6', '110', '11', NULL, NULL, NULL, 5),
(43, 't-shirt', 400, 2, 'http://localhost/admin2/uploads/t4.jpg', 'tshirt', 12, '6', '110', '11', NULL, NULL, NULL, 5),
(44, 'toys', 200, 1, 'http://localhost/admin2/uploads/view-3d-train-model-with-simple-colored-background_23-2151157158.jpg', 'playing toys', 50, '7', '114', '22', NULL, NULL, NULL, 5),
(45, 'toys', 200, 5, 'http://localhost/admin2/uploads/3226565.jpg', 'play with toys and enjoy your day', 1, '7', '114', '22', NULL, NULL, NULL, 5),
(46, 't-shirt', 500, 1, 'http://localhost/admin2/uploads/t31.jpg', 'tshirt', 30, '7', '115', '23', NULL, NULL, NULL, 5),
(47, 't-shirt', 500, 1, 'http://localhost/admin2/uploads/t41.jpg', 'tshirt', 45, '7', '115', '23', NULL, NULL, NULL, 5),
(48, 't-shirt', 500, 1, 'http://localhost/admin2/uploads/t21.jpg', 'tshirt', 12, '7', '115', '23', NULL, NULL, NULL, 5),
(49, 't-shirt', 500, 2, 'http://localhost/admin2/uploads/t11.jpg', 'tshirt', 15, '7', '115', '23', NULL, NULL, NULL, 5),
(50, 'toys', 200, 1, 'http://localhost/admin2/uploads/32265651.jpg', 'play with toys', 50, '7', '115', '24', NULL, NULL, NULL, 5),
(51, 'hp laptop', 40000, 1, 'http://localhost/admin2/uploads/images.jpeg', 'hp laptops', 50, '3', '111', '15', NULL, NULL, NULL, 5),
(52, 'laptop', 500000, 1, 'http://localhost/admin2/uploads/images_(1).jpeg', 'lenovo laptops', 34, '3', '111', '16', NULL, NULL, NULL, 5),
(53, 'apple laptops', 100000, 1, 'http://localhost/admin2/uploads/images_(1)1.jpeg', 'apple laptops', 30, '3', '111', '17', NULL, NULL, NULL, 5),
(54, 'oppo phones', 20000, 1, 'http://localhost/admin2/uploads/images_(3).jpeg', 'oppo oppo phones', 45, '3', '105', '4', NULL, NULL, NULL, 5),
(55, 'vivo phones', 20000, 1, 'http://localhost/admin2/uploads/images_(5).jpeg', 'vivo phones', 45, '3', '105', '12', NULL, NULL, NULL, 5),
(56, 'micromax phn', 50000, 2, 'http://localhost/admin2/uploads/images_(2).jpeg', 'micromax relival phones', 50, '3', '105', '13', NULL, NULL, NULL, 5),
(57, 'vivo phone', 4635, 1, 'http://localhost/admin2/uploads/images_(5)1.jpeg', 'made in china', 34, '3', '105', '12', NULL, NULL, NULL, 5),
(58, 'digital camera', 25000, 1, 'http://localhost/admin2/uploads/c12.jpg', 'camera', 34, '3', '112', '29', NULL, NULL, NULL, 5),
(59, 'camera', 20000, 1, 'http://localhost/admin2/uploads/c2.jpg', 'camera for beatiful moments', 50, '3', '112', '30', NULL, NULL, NULL, 5),
(60, 'head phones', 2000, 1, 'http://localhost/admin2/uploads/images_(6).jpeg', 'head phones ', 32, '3', '116', '26', NULL, NULL, NULL, 5),
(62, 'ear dopes kirti', 10002, 1, '', 'ear dopes digital-music-products-electronic-equipment-', 45, '3', '116', '27', NULL, NULL, NULL, 5),
(63, '0pp0', 10, 1, 'http://localhost/admin2/uploads/best-product-33.jpg', '000ppppppp0000', 50, '1', '103', '1', NULL, NULL, NULL, 5),
(64, 'hindi book', 100, 0, 'http://localhost/admin2/uploads/pngtree-in-ear-headphones-digital-music-products-electronic-equipment-png-image_39812627.png', 'jackets woolen', 6, '1', '103', '1', NULL, NULL, NULL, 5);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(225) DEFAULT NULL,
  `id` int(255) NOT NULL,
  `rid` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`password`, `created_at`, `email`, `id`, `rid`) VALUES
('lucky123', '2024-02-26 07:06:50', 'mahadev@gmail.com', 2, 12),
('987456321', '2024-02-26 08:51:21', 'guptakirti@gmail.com', 4, 13),
('987456321', '2024-02-26 09:02:43', 'shashank01@gmail.com', 5, 14),
('987456321', '2024-02-26 09:12:29', 'guptakirti@gmail.com', 6, 15),
('11110000', '2024-02-26 09:55:57', 'anchal@gmail.com', 7, 16),
('kirti010101', '2024-05-01 10:36:11', 'akanksha@gmail.com', 8, 17);

-- --------------------------------------------------------

--
-- Table structure for table `registerinfo`
--

CREATE TABLE `registerinfo` (
  `rid` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `tname` varchar(255) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `flag` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `dob` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registerinfo`
--

INSERT INTO `registerinfo` (`rid`, `name`, `sname`, `tname`, `mobile`, `address`, `gender`, `flag`, `created_at`, `dob`) VALUES
(12, 'mahadev', '', 'baba', '8576085487', 'pratapgarh , U.P.', 'female', 'TRUE', '2024-02-26 07:06:50', '0000-00-00'),
(13, 'Kirti ', 'k', 'gupta', '8576085487', 'pratapgarh , U.P.', 'female', 'TRUE', '2024-02-26 08:51:21', '0000-00-00'),
(14, 'shashank', '', 'gupta', '8576085487', 'pratapgarh , U.P.', 'female', 'TRUE', '2024-02-26 09:02:43', '1992-06-09'),
(15, 'Kirti ', '', 'gupta', '8576085487', 'pratapgarh , U.P.', 'female', 'TRUE', '2024-02-26 09:12:29', '2000-12-01'),
(16, 'anchal', '', 'sahu', '8576085487', 'pratapgarh , U.P.', 'female', 'TRUE', '2024-02-26 09:55:57', '0000-00-00'),
(17, 'Akansha ', 'gupta', '', '8576085487', 'pratapgarh , U.P.', 'female', 'TRUE', '2024-05-01 10:36:11', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `review` text NOT NULL,
  `star` text NOT NULL,
  `product_id` int(255) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `name`, `email`, `review`, `star`, `product_id`, `date`) VALUES
(1, 'mahadev', 'mahadev@gmail.com', 'har har mahadev', '4', 1, '2024-02-20 07:02:42'),
(60, 'Kirti sahu', 'sahukirti265@gmail.com', 'kirti \'s says that this is good products ', '5', 31, '2024-03-04 04:55:34'),
(61, 'sadhvi', 'sadhvi@gmail.com', 'good products ', '3', 28, '2024-03-04 04:59:37'),
(63, 'mahadev', 'mahadev@gmail.com', 'har har mahadev ji ', '2', 28, '2024-03-04 05:16:54'),
(64, 'Kirti sahu', 'sahukirti265@gmail.com', 'first ', '4', 28, '2024-03-04 07:58:22'),
(65, 'misskittu ', 'sahukirti265@gmail.com', 'missttu', '4', 28, '2024-03-04 09:02:57'),
(66, 'aman', 'aman@gmail.com', 'naman ', '4', 28, '2024-03-04 09:04:36'),
(67, 'arav', 'aravgupta@gmail.com', 'good', '3', 28, '2024-03-04 09:07:04'),
(68, 'naman', 'naman@gmail.com', 'rdftgyhj', '3', 28, '2024-03-04 09:09:20'),
(70, 'Kirti sahu', 'sahukirti265@gmail.com', 'nice product', '5', 22, '2024-03-09 15:19:28'),
(71, 'kirti sahu ', 'sahukirti265@gmail.com', 'very nice camera and that feature is very nice . if u want some unique and better model then u should purchase the camera ....', '5', 58, '2024-03-12 05:26:52');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(255) NOT NULL,
  `category_id` text DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `active_inactive` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`, `active_inactive`) VALUES
(103, '1', 'books', 'on'),
(104, '4', 'lunch', 'on'),
(105, '3', 'mobile', 'on'),
(108, '6', 'men dresss', 'on'),
(109, '6', 'women dresss', 'on'),
(110, '6', 'children dresss', 'on'),
(111, '3', 'laptop', 'on'),
(112, '3', 'camera', 'on'),
(113, '1', 'pens', 'on'),
(114, '7', 'baby girl', 'on'),
(115, '7', 'baby boy', 'on'),
(116, '3', 'ear phones', 'on');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `billing_details`
--
ALTER TABLE `billing_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cartitems`
--
ALTER TABLE `cartitems`
  ADD PRIMARY KEY (`CartItemID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `categoris`
--
ALTER TABLE `categoris`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `childcategories`
--
ALTER TABLE `childcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`fID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_user`
--
ALTER TABLE `login_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registerinfo`
--
ALTER TABLE `registerinfo`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `bid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `billing_details`
--
ALTER TABLE `billing_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cartitems`
--
ALTER TABLE `cartitems`
  MODIFY `CartItemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cid` bigint(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categoris`
--
ALTER TABLE `categoris`
  MODIFY `cid` bigint(225) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `childcategories`
--
ALTER TABLE `childcategories`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `fID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_user`
--
ALTER TABLE `login_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `registerinfo`
--
ALTER TABLE `registerinfo`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
